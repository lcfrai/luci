import React from 'react';
import {afterEach,beforeEach,expect,it,vi} from 'vitest';
import {act,cleanup,fireEvent,render,screen,waitFor} from '@testing-library/react';
import {readFileSync} from 'node:fs';
import {DefinitionWorkspace} from '/workspace/luci/desktop/src/components/definition/DefinitionWorkspace';
import {definitionApi,type ProjectSpecification} from '/workspace/luci/desktop/src/api/definition';
import {productApi} from '/workspace/luci/desktop/src/api/product';
import {resetCockpit} from '/workspace/luci/desktop/src/store/store';
import {purposeControl} from '/workspace/.luci-tools/cloud060-real-browser-v3/purpose.mjs';
const current=vi.hoisted(()=>({owner:'owner-a',permissions:{read:true,edit:true,execute:true,secrets:true,deploy:true,admin:true}}));
vi.mock('/workspace/luci/desktop/src/components/auth/AuthProvider',()=>({useAuth:()=>({profile:{user:{id:current.owner}}})}));
vi.mock('/workspace/luci/desktop/src/components/setup/SetupProvider',()=>({useSetup:()=>({status:{access:{user:{username:current.owner}},config:{projectsDir:'/controlled-projects'}}})}));
vi.mock('/workspace/luci/desktop/src/components/teams/TeamWorkspaceProvider',()=>({useTeamProjectPermissions:()=>({loading:false,error:'',permissions:current.permissions}),useTeamWorkspace:()=>null}));
const pinned=readFileSync('/workspace/.luci-tools/cloud064-purpose-selector/pinned-injected.cjs','utf8');
// The entire pinned source is evaluated unchanged. Only the wrapper returns
// existing lexical symbols; no replacement label/name algorithm is supplied.
const engine=new Function('module','exports',pinned+'\nreturn {InjectedScript,SelectorEvaluatorImpl,createRoleEngine,getElementLabels,elementText,setGlobalOptions};')({exports:{}},{});
engine.setGlobalOptions({browserNameForWorkarounds:'chromium'});
function label(root:Document|Element=document){const evaluator=new engine.SelectorEvaluatorImpl();return engine.InjectedScript.prototype._createInternalLabelEngine.call({_evaluator:evaluator}).queryAll(root,'"The idea"s') as Element[];}
function role(root:Document|Element=document){return engine.createRoleEngine(true).queryAll(root,'textbox[name="The idea"s]') as Element[];}
const page={locator:(selector:string)=>({getByRole:(kind:string,options:{name:string;exact:boolean})=>{expect(kind).toBe('textbox');expect(options).toEqual({name:'The idea',exact:true});return {all:()=>Array.from(document.querySelectorAll(selector)).flatMap(root=>role(root))};}})};
const matched=(team='team-fixture',project='p-alpha')=>purposeControl(page,team,project).all() as HTMLTextAreaElement[];
const fixture=(project='p-alpha',purpose=`Saved ${current.owner} ${project} purpose`):ProjectSpecification=>({projectId:project,version:1,revision:2,briefRevision:3,startingPoint:'new',purpose,audience:'People',constraints:'Offline',outOfScope:[],requirements:[{id:'AC-1',title:'Retain work',priority:'must',acceptance:'Saved work survives reopening'}],journeys:[],roles:[],entities:[],integrations:[],glossary:[],decisions:[],questions:[],status:'draft',digest:'',updatedAt:''});
function Scope({project='p-alpha',team='team-fixture',hidden=false,selected=true}:{project?:string;team?:string;hidden?:boolean;selected?:boolean}){return <div className="team-app-host" hidden={hidden}><select id="team-workspace" value={team} onChange={()=>{}}><option value={team}>{team}</option></select><div role="treeitem" data-kind="project" data-id={project} aria-selected={selected}/><DefinitionWorkspace projectId={project}/></div>;}
beforeEach(()=>{localStorage.clear();resetCockpit();current.owner='owner-a';Object.assign(current.permissions,{read:true,edit:true,execute:true,secrets:true,deploy:true,admin:true});vi.spyOn(definitionApi,'get').mockImplementation(async id=>fixture(id));vi.spyOn(definitionApi,'listAssistance').mockResolvedValue({jobs:[]});vi.spyOn(productApi,'agentConnections').mockResolvedValue({revision:0,activeConnectionId:'',connections:[]});vi.spyOn(productApi,'agents').mockResolvedValue({providers:[]});});
afterEach(()=>{cleanup();vi.restoreAllMocks();});
const loaded=async()=>await screen.findByRole('textbox',{name:'The idea',exact:true}) as HTMLTextAreaElement;
it('CLOUD064 exact pinned label engine misses nonempty actual purpose while exact role engine selects it',async()=>{
 const save=vi.spyOn(definitionApi,'save'),assist=vi.spyOn(definitionApi,'assist');render(<Scope/>);const target=await loaded();
 expect(target.value).toBe('Saved owner-a p-alpha purpose');expect(target.parentElement?.tagName).toBe('LABEL');
 const labels=engine.getElementLabels(new Map(),target);expect(labels.map((row:any)=>row.normalized)).toEqual(['The ideaSaved owner-a p-alpha purpose']);
 expect(label()).toEqual([]);expect(role()).toEqual([target]);expect(matched()).toEqual([target]);expect(save).not.toHaveBeenCalled();expect(assist).not.toHaveBeenCalled();
});
it('CLOUD064 empty actual purpose is a positive exact-label control, not a broad label failure',async()=>{
 vi.mocked(definitionApi.get).mockResolvedValue(fixture('p-alpha',''));render(<Scope/>);const target=await loaded();expect(label()).toEqual([target]);expect(role()).toEqual([target]);expect(matched()).toEqual([target]);
});
it('CLOUD064 edited real draft retains exact role identity and saves only its own project after explicit action',async()=>{
 const save=vi.spyOn(definitionApi,'save').mockImplementation(async(_id,value)=>({...value,revision:3,briefRevision:4}));render(<Scope/>);const target=await loaded();
 fireEvent.change(target,{target:{value:'Private alpha amendment'}});await waitFor(()=>expect(target.value).toBe('Private alpha amendment'));
 expect(matched()).toEqual([target]);expect(label()).toEqual([]);expect(role()).toEqual([target]);expect(save).not.toHaveBeenCalled();
 fireEvent.click(screen.getByRole('button',{name:'Save definition',exact:true}));await waitFor(()=>expect(save).toHaveBeenCalledOnce());expect(save.mock.calls[0][0]).toBe('p-alpha');expect(save.mock.calls[0][1].purpose).toBe('Private alpha amendment');
});
it('CLOUD064 actual helper refuses wrong team, wrong project, hidden host and unselected project',async()=>{
 const view=render(<Scope/>);const target=await loaded();expect(matched()).toEqual([target]);expect(matched('team-other')).toEqual([]);expect(matched('team-fixture','p-other')).toEqual([]);
 view.rerender(<Scope hidden/>);expect(matched()).toEqual([]);expect(role()).toEqual([]);
 view.rerender(<Scope selected={false}/>);expect(matched()).toEqual([]);
 view.rerender(<Scope/>);expect(matched()).toEqual([target]);
});
it('CLOUD064 actual component keeps project and owner drafts separate while semantic lookup follows current scope',async()=>{
 const view=render(<Scope/>);let target=await loaded();fireEvent.change(target,{target:{value:'Private owner-a alpha draft'}});
 view.rerender(<Scope project="p-beta"/>);await waitFor(()=>expect((screen.getByRole('textbox',{name:'The idea',exact:true}) as HTMLTextAreaElement).value).toBe('Saved owner-a p-beta purpose'));
 expect(matched()).toEqual([]);target=matched('team-fixture','p-beta')[0];expect(target.value).toBe('Saved owner-a p-beta purpose');fireEvent.change(target,{target:{value:'Private owner-a beta draft'}});
 current.owner='owner-b';view.rerender(<Scope project="p-beta"/>);await waitFor(()=>expect(matched('team-fixture','p-beta')[0]?.value).toBe('Saved owner-b p-beta purpose'));
 expect(document.body.textContent).not.toContain('Private owner-a');expect(screen.queryByRole('button',{name:'Restore draft',exact:true})).toBeNull();
 current.owner='owner-a';view.rerender(<Scope/>);await screen.findByRole('region',{name:'Definition draft recovery'});fireEvent.click(screen.getByRole('button',{name:'Restore draft',exact:true}));await waitFor(()=>expect(matched()[0]?.value).toBe('Private owner-a alpha draft'));
});
it('CLOUD064 malformed scope identifiers cannot broaden the actual helper locator',()=>{
 for(const id of ['', 'team-fixture"] *', '../p-alpha']){expect(()=>matched(id)).toThrow();expect(()=>matched('team-fixture',id)).toThrow();}
});
