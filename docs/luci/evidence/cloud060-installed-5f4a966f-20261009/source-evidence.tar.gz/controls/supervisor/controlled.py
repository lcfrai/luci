#!/usr/bin/env python3
"""Inert source-bound supervisor controls; never launches application processes."""
import contextlib
import importlib.util
import io
import json
import os
import pathlib
import tempfile
import types
import unittest
from unittest import mock

SOURCE = pathlib.Path(os.environ["C060_SUPERVISOR_SOURCE"])
spec = importlib.util.spec_from_file_location("c060_supervisor_controlled", SOURCE)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
PRODUCT = "a" * 40


class SupervisorControls(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="c060-supervisor-control-")
        self.addCleanup(self.temp.cleanup)
        self.base = pathlib.Path(self.temp.name).resolve()
        self.base.chmod(0o700)

    def owner(self):
        root = self.base / "run"
        root.mkdir(mode=0o700)
        ev = m.Evidence(root)
        self.addCleanup(ev.close)
        own = m.Ownership(root, ev, PRODUCT)
        return root, ev, own

    def scopes(self, root):
        rows = []
        for kind, ident in (("user", "user-AAAAAAAAAAAAAAAAAAAAAA"),
                            ("team", "team-BBBBBBBBBBBBBBBBBBBBBB")):
            collection = "users" if kind == "user" else "teams"
            rows.append({"kind": kind, "id": ident, "stateDir": str(
                root / "state" / "control-plane" / collection / ident / "runtime" / "state")})
        return {"version": 1, "product": PRODUCT, "runRoot": str(root), "scopes": rows}

    def publish(self, root, value):
        path = root / "driver-managed-scopes.json"
        path.write_text(json.dumps(value))
        path.chmod(0o600)

    def environment(self, root, scope):
        pairs = {"LUCI_WORKER": "1", "LUCI_MANAGED_WORKER": "1",
                 "LUCI_STATE_DIR": scope["stateDir"],
                 "LUCI_EXECUTION_AUTHORITY_FILE": str(root / "state/control-plane/identity.json")}
        if scope["kind"] == "user":
            pairs.update(LUCI_ACTOR_ID=scope["id"], LUCI_ACTOR_ROLE="member")
        else:
            pairs["LUCI_TEAM_ID"] = scope["id"]
        return {k.encode(): v.encode() for k, v in pairs.items()}

    def entries(self, values):
        return [key + b"=" + val for key, val in values.items()]

    def test_bare_receipt_names_write_fsynced_exclusive_json(self):
        root, ev, _ = self.owner()
        with mock.patch.object(m.os, "fsync", wraps=os.fsync) as fsync:
            receipt = ev.exclusive("preflight", {"passed": False})
        self.assertEqual(receipt["path"], "supervisor/preflight.json")
        self.assertEqual(json.loads((root / receipt["path"]).read_text()), {"passed": False})
        self.assertGreaterEqual(fsync.call_count, 2)
        with self.assertRaises(FileExistsError):
            ev.exclusive("preflight", {"passed": True})
        with self.assertRaises(ValueError):
            ev.exclusive("../escape", {})

    def test_no_launch_preflight_failure_persists_exception_cleanup_and_final(self):
        repo, artifacts, parent = (self.base / name for name in ("repo", "artifacts", "parent"))
        for path in (repo, artifacts, parent):
            path.mkdir(mode=0o700)
        executable = self.base / "inert-executable"
        executable.write_text("This fixture is never executed.\n")
        executable.chmod(0o700)
        args = types.SimpleNamespace(repo=str(repo), artifacts=str(artifacts), parent=str(parent),
            chromium=str(executable), product=PRODUCT, window_granted=True)
        empty_scan = {"at": "controlled", "matched": [], "issues": [], "issueCount": 0,
            "scanned": 0, "otherUIDSkipped": 0, "complete": True,
            "managedScopeLedger": {"status": "absent"}}
        with (mock.patch.object(m, "git_head", return_value="b" * 40),
              mock.patch.object(m.shutil, "which", return_value=str(executable)),
              mock.patch.object(m.Ownership, "scan", return_value=empty_scan),
              mock.patch.object(m.subprocess, "Popen", side_effect=AssertionError("No child allowed")) as spawn,
              mock.patch.object(m.signal, "pidfd_send_signal", side_effect=AssertionError("No signal allowed")) as signals,
              contextlib.redirect_stdout(io.StringIO()) as stdout):
            result = m.run(args)
        self.assertEqual(result, 1)
        spawn.assert_not_called()
        signals.assert_not_called()
        roots = list(parent.iterdir())
        self.assertEqual(len(roots), 1)
        for name in ("preflight", "exception", "cleanup-entered", "final"):
            self.assertTrue((roots[0] / "supervisor" / (name + ".json")).is_file(), name)
        final = json.loads((roots[0] / "supervisor/final.json").read_text())
        self.assertFalse(final["passed"])
        self.assertFalse(final["runtimeExecuted"])
        self.assertIn("supervisor-exception", final["reasons"])
        self.assertEqual(final["returnCode"], None)
        self.assertFalse(json.loads(stdout.getvalue())["passed"])
        for name in ("driver-home", "driver-tmp", "driver-config", "driver-cache", "driver-data", "driver-runtime"):
            self.assertEqual((roots[0] / name).stat().st_mode & 0o777, 0o700)

    def test_markerless_user_and_team_require_exact_production_scope_fields(self):
        root, _, own = self.owner()
        ledger = self.scopes(root)
        self.publish(root, ledger)
        self.assertEqual(own.scope_ledger()["status"], "read")
        for scope in ledger["scopes"]:
            with self.subTest(kind=scope["kind"]):
                values = self.environment(root, scope)
                self.assertNotIn(b"LUCI_C060_RUN_ROOT", values)
                self.assertEqual(own.managed_match(self.entries(values)), scope)

    def test_wrong_missing_duplicate_foreign_and_opposite_scope_fields_refused(self):
        root, _, own = self.owner()
        ledger = self.scopes(root)
        self.publish(root, ledger)
        own.scope_ledger()
        cases = [
            (0, b"LUCI_ACTOR_ID", b"foreign"), (1, b"LUCI_TEAM_ID", b"foreign"),
            (0, b"LUCI_TEAM_ID", b""), (1, b"LUCI_ACTOR_ID", b""),
            (1, b"LUCI_ACTOR_ROLE", b"member"), (0, b"LUCI_WORKER", b"0"),
            (1, b"LUCI_MANAGED_WORKER", None), (0, b"LUCI_STATE_DIR", b"/foreign/state"),
            (1, b"LUCI_EXECUTION_AUTHORITY_FILE", b"/foreign/identity.json"),
            (0, b"LUCI_ACTOR_ID", None), (1, b"LUCI_TEAM_ID", None)]
        for idx, key, value in cases:
            with self.subTest(index=idx, key=key, value=value):
                values = self.environment(root, ledger["scopes"][idx])
                if value is None:
                    values.pop(key, None)
                else:
                    values[key] = value
                self.assertIsNone(own.managed_match(self.entries(values)))
        values = self.environment(root, ledger["scopes"][0])
        self.assertIsNone(own.managed_match(self.entries(values) + [b"LUCI_WORKER=1"]))
        values[b"LUCI_STATE_DIR"] += b"/descendant"
        self.assertIsNone(own.managed_match(self.entries(values)))

    def test_scope_ledger_change_missing_or_escape_is_not_accepted(self):
        root, _, own = self.owner()
        ledger = self.scopes(root)
        self.publish(root, ledger)
        first = own.scope_ledger()
        self.assertEqual(first["status"], "read")
        ledger["scopes"][0]["id"] = "other"
        self.publish(root, ledger)
        self.assertEqual(own.scope_ledger()["status"], "unknown")
        self.assertEqual(own.managed_scope_digest, first["sha256"])
        (root / "driver-managed-scopes.json").unlink()
        self.assertEqual(own.scope_ledger()["status"], "unknown")
        self.assertIsNotNone(own.managed_scope_error)

    def test_markerless_scope_scan_persists_exact_identity_after_environment_disappears(self):
        root, _, own = self.owner()
        ledger = self.scopes(root)
        self.publish(root, ledger)
        scope = ledger["scopes"][1]
        payload = b"\0".join(self.entries(self.environment(root, scope))) + b"\0"
        pid, fakefd = 99999999, 99999998
        current = {"status": "present", "pid": pid, "startTicks": 31415,
                   "state": "S", "parentPid": 1, "uid": os.getuid()}
        real_open, real_read, real_close = os.open, os.read, os.close
        chunks = []
        def fake_open(path, flags, *args, **kwargs):
            if str(path) == f"/proc/{pid}/environ":
                chunks[:] = [payload, b""]
                return fakefd
            return real_open(path, flags, *args, **kwargs)
        def fake_read(fd, count):
            return chunks.pop(0) if fd == fakefd else real_read(fd, count)
        def fake_close(fd):
            return None if fd == fakefd else real_close(fd)
        with (mock.patch.object(m, "read_identity", return_value=current),
              mock.patch.object(m.os, "scandir", return_value=contextlib.nullcontext([types.SimpleNamespace(name=str(pid))])),
              mock.patch.object(m.os, "open", side_effect=fake_open),
              mock.patch.object(m.os, "read", side_effect=fake_read),
              mock.patch.object(m.os, "close", side_effect=fake_close)):
            report = own.scan()
        self.assertTrue(report["complete"])
        self.assertEqual(report["matched"][0]["origin"], "exact-managed-scope")
        self.assertEqual(report["matched"][0]["managedScope"], scope)
        self.assertEqual(own.known[(pid, 31415)]["role"], "managed-team-runtime")
        with mock.patch.object(m, "read_identity", return_value={"status": "absent", "pid": pid}):
            settled = own.observations()
        self.assertEqual(settled[0]["expected"]["startTicks"], 31415)
        self.assertEqual(settled[0]["observed"]["status"], "absent")


if __name__ == "__main__":
    unittest.main(verbosity=2)
