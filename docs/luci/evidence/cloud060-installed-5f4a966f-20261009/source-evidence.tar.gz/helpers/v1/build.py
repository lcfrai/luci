#!/usr/bin/env python3
"""Prepared source-build receipt generator. NOT executed by its author.
Requires a clean, isolated exact checkout and explicit root scheduling approval.
Writes private build outputs/failed receipts, never a release or installation.
"""
import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, sys, time, tarfile
P=pathlib.Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--artifacts',required=True);p.add_argument('--product',required=True);p.add_argument('--window-granted',action='store_true');p.add_argument('--isolated-checkout',action='store_true');p.add_argument('--reuse-package-provenance');a=p.parse_args()
assert a.window_granted and a.isolated_checkout,'Explicit quiet build slot and isolated checkout required'
assert os.getuid()!=0,'Build and runtime must use the same isolated non-root fixture account'
assert re.fullmatch('[a-f0-9]{40}',a.product)
repo=P(a.repo).resolve(strict=True);out=P(a.artifacts).absolute();here=P(__file__).resolve().parent
assert not out.exists() and repo not in out.parents and out.parent.resolve()==out.parent
out.mkdir(mode=0o700);os.umask(0o077)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True,timeout=20).strip()
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def rows(root,paths):
 result=[]
 for name in sorted(set(paths)):
  path=root/name;assert path.resolve()==path and path.is_file(),name
  result.append({'path':name,'sha256':digest(path),'bytes':path.stat().st_size})
 return result
receipt={'version':1,'product':a.product,'passed':False,'scope':'Actual source build only; no package/native/provider/browser acceptance','commands':[]}
try:
 assert git('rev-parse','HEAD')==a.product;assert not git('status','--porcelain','--untracked-files=no')
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo,timeout=20).decode().split('\0')
 selected=[x for x in tracked if x and (x.startswith(('control-plane/','sandboxd/','desktop/')) or x in ['go.work','go.work.sum','LICENSE'])]
 # Bind the actual imported relative helper closure, including transitively
 # imported modules even when this scenario calls only stopControllerTree.
 seeds=['scripts/acceptance/launch-recovery/acceptance-lifecycle.mjs','scripts/acceptance/launch-recovery/acceptance-startup.mjs','scripts/acceptance/check-create-recovery/installed-recovery.mjs'];closure=set()
 while seeds:
  name=seeds.pop()
  if name in closure:continue
  source=repo/name;assert source.is_file() and not source.is_symlink();closure.add(name)
  text=source.read_text()
  for spec in re.findall(r"(?:from\s*|import\s*\(|import\s*)['\"](\.[^'\"]+)['\"]",text):
   child=(source.parent/spec).resolve();assert repo in child.parents and child.is_file(),spec
   seeds.append(str(child.relative_to(repo)))
 receipt['sourceInputs']=rows(repo,selected+list(closure));receipt['helperRepositoryClosure']=sorted(closure)
 receipt['helperInputs']=rows(here,[x.name for x in here.iterdir() if x.is_file() and x.suffix in ['.mjs','.py','.md']])
 # Tool dependency files are captured after locked npm installation, before build.
 env={k:os.environ[k] for k in ['PATH','LANG','LC_ALL','TZ','GOROOT'] if k in os.environ}
 for name in ['home','tmp','cache','go-cache','go-mod-cache','npm-cache']:(out/name).mkdir(mode=0o700)
 env.update(HOME=str(out/'home'),TMPDIR=str(out/'tmp'),GOCACHE=str(out/'go-cache'),GOMODCACHE=str(out/'go-mod-cache'),GOMAXPROCS='2',npm_config_cache=str(out/'npm-cache'),CI='true',PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD='1')
 def command(name,argv,cwd,budget):
  row={'name':name,'argv':argv,'cwdScope':'desktop' if cwd==repo/'desktop' else 'repository','timeoutSeconds':budget,'startedAt':time.time()};receipt['commands'].append(row)
  with (out/(name+'.stdout.log')).open('xb') as stdout,(out/(name+'.stderr.log')).open('xb') as stderr:
   child=subprocess.Popen(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   row['pid']=child.pid
   try:row['exitCode']=child.wait(timeout=budget)
   except subprocess.TimeoutExpired:
    row['timeout']=True;os.killpg(child.pid,15)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,9);child.wait(timeout=10)
    raise RuntimeError(name+' timed out')
   finally:row['endedAt']=time.time()
  assert row['exitCode']==0,name+' failed'
 if not a.reuse_package_provenance:command('npm-ci',['npm','ci','--no-audit','--fund=false'],repo/'desktop',600)
 dependency=[]
 for name in ['playwright','playwright-core','axe-core']:
  root=repo/'desktop/node_modules'/name;assert root.is_dir()
  dependency.extend(str(x.relative_to(repo)) for x in root.rglob('*') if x.is_file() and not x.is_symlink())
 receipt['runtimeDependencyInputs']=rows(repo,dependency)
 if a.reuse_package_provenance:
  # Reuse only a publisher-bound CLEAN exact-SHA archive. Verify every selected
  # binary/web member against both original archive and extracted package.
  provenance_path=P(a.reuse_package_provenance).resolve(strict=True);assert provenance_path.is_file()
  provenance_hash=digest(provenance_path);provenance=json.loads(provenance_path.read_text());assert provenance['sourceCommit']==a.product and provenance['sourceDirty'] is False
  package=P(provenance['packageDir']).resolve(strict=True);archive=P(provenance['archive']).resolve(strict=True)
  assert digest(archive)==provenance['archiveSHA256'];assert digest(package/'luci')==provenance['binarySHA256'];assert digest(package/'web/index.html')==provenance['webIndexSHA256']
  selected_members={}
  with tarfile.open(archive,'r:*') as tar:
   for member in tar:
    name=member.name
    if name!='luci' and not name.startswith('web/'):continue
    assert not name.startswith('/') and '..' not in P(name).parts
    if member.isdir():continue
    assert member.isfile() and name not in selected_members
    stream=tar.extractfile(member);assert stream is not None
    h=hashlib.sha256();total=0
    for block in iter(lambda:stream.read(1024*1024),b''):h.update(block);total+=len(block)
    assert total==member.size;original=package/name;assert original.resolve()==original and original.is_file()
    assert digest(original)==h.hexdigest();selected_members[name]={'sha256':h.hexdigest(),'bytes':total}
  assert 'luci' in selected_members and 'web/index.html' in selected_members
  actual={'luci'}|{str(x.relative_to(package)) for x in (package/'web').rglob('*') if x.is_file()}
  assert actual==set(selected_members),'Selected package file set differs from archive'
  for name,binding in selected_members.items():
   target=out/name;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700);shutil.copyfile(package/name,target);target.chmod(0o700 if name=='luci' else 0o600)
   assert digest(target)==binding['sha256'] and target.stat().st_size==binding['bytes']
  assert digest(archive)==provenance['archiveSHA256'] and digest(provenance_path)==provenance_hash,'Package provenance/archive changed during verification'
  receipt['reuse']={'mode':'verified-existing-package','provenanceSHA256':digest(provenance_path),'archiveSHA256':provenance['archiveSHA256'],'sourceCommit':provenance['sourceCommit'],'sourceDirty':False,'selectedMemberCount':len(selected_members),'buildOrigin':'Publisher clean-build statement; exact archive/extracted/copy binary+web bytes independently checked here; no new build executed'}
 else:
  command('web-build',['npm','run','build','--','--outDir',str(out/'web')],repo/'desktop',600)
  command('api-build',['go','build','-trimpath','-o',str(out/'luci'),'./control-plane/cmd/api'],repo,600)
 assert (out/'web/index.html').is_file() and (out/'luci').is_file()
 receipt['outputs']=rows(out,['luci']+[str(x.relative_to(out)) for x in (out/'web').rglob('*') if x.is_file()])
 assert receipt['sourceInputs']==rows(repo,[x['path'] for x in receipt['sourceInputs']]);assert git('rev-parse','HEAD')==a.product;assert not git('status','--porcelain','--untracked-files=no')
 receipt['sourceStable']=True;receipt['passed']=True
except BaseException as e:
 receipt['failure']={'type':type(e).__name__,'messageSHA256':hashlib.sha256(str(e).encode()).hexdigest()};raise
finally:
 receipt['endedAt']=time.time();write(out/'build-receipt.json',receipt)
