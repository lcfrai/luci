// PREPARED / NOT EXECUTED. Real source API authority changes and actual portals.
// No session records, workers, credentials or provider outputs are manufactured.
import assert from 'node:assert/strict';
import {setTimeout as delay} from 'node:timers/promises';
import {emptyGrants,assertEmptySessions,assertEpisodeTraffic,denialProjection,assertHeldEarlyObservation,budgets} from './guards.mjs';
import {sha,createBackgroundFence} from './capture.mjs';
import {clickRailControl} from './navigation.mjs';
export async function runScenario({page,context,base,request,owner,member,team,project,record,health,fail,onPhase,evidence,axeSource}){
 const workspace=`/v1/teams/${team.id}/workspace`,sessionPath=workspace+'/v1/sessions';
 let mode='pass',held=null,release=null,gateTimer=null,focusEvents=0,membershipReads=0;
 const network=[],background=createBackgroundFence(fail);
 const observe=async response=>{const path=new URL(response.url()).pathname;if(!['/v1/teams',sessionPath,workspace+'/v1/projects'].includes(path))return;const bytes=await response.body();assert(bytes.length<=budgets.bodyBytes);const row={path,status:response.status(),at:Date.now(),sha256:sha(bytes),bytes:bytes.length};if(path===sessionPath&&row.status===403)Object.assign(row,denialProjection(row.status,bytes));assert(network.length<256);network.push(row);record({kind:'catalogue-response',...row});};
 const onResponse=response=>background.track(()=>observe(response));page.on('response',onResponse);
 await page.exposeFunction('__luciFixtureFocus',()=>{focusEvents++;});
 await page.addInitScript(()=>window.addEventListener('focus',()=>void globalThis.__luciFixtureFocus()));
 const route=async route=>{
  try{
   health();background.check();if(route.request().method()!=='GET')return route.fallback();membershipReads++;
   if(mode==='abort'){mode='pass';record({kind:'explicit-fault-injection',fault:'abort-next-membership-read'});return route.abort('failed');}
   if(mode!=='hold')return route.fallback();mode='pass';
   // This fetch returns the real authoritative body. No fabricated membership.
   const response=await route.fetch({timeout:budgets.httpMs});health();const body=await response.body();assert(body.length<=budgets.bodyBytes);
   const value=JSON.parse(body);assert(Array.isArray(value.teams)&&!value.teams.some(row=>row.team.id===team.id));
   const start=Date.now();held={status:response.status(),sha256:sha(body),bytes:body.length,startedAt:start,expiresAt:start+budgets.gateMs,released:false};record({kind:'real-membership-response-held',...held});
   await new Promise(resolve=>{release=resolve;gateTimer=setTimeout(resolve,budgets.gateMs);});health();held.released=true;clearTimeout(gateTimer);
   await route.fulfill({response,body});record({kind:'real-membership-response-released',...held});
  }catch(error){fail(error);await route.abort('failed').catch(()=>{});}
 };
 await context.route(base+'/v1/teams',route);
 const until=async(label,fn,ms=15000)=>{const end=Date.now()+ms;while(Date.now()<end){health();background.check();if(await fn())return;await delay(60);}throw Error(label);};
 const change=async action=>{const current=await request('GET','/v1/teams/'+team.id,undefined,200,owner.token);return action==='remove'?request('DELETE',`/v1/teams/${team.id}/members/${member.id}`,{expectedRevision:current.team.revision},200,owner.token):request('POST',`/v1/teams/${team.id}/members`,{expectedRevision:current.team.revision,username:member.username,role:'editor',grants:emptyGrants},200,owner.token);};
 const grant=async()=>{const current=await request('GET','/v1/teams/'+team.id,undefined,200,owner.token);return request('PUT',`/v1/teams/${team.id}/projects/${project.id}/members/${member.id}`,{expectedRevision:current.team.revision,role:'editor',grants:emptyGrants},200,owner.token);};
 const purpose=()=>page.getByLabel('The idea',{exact:true});
 const railControl=name=>clickRailControl({page,teamId:team.id,name,health:()=>{health();background.check();},record});
 async function openProject(){await railControl('All projects');await page.getByRole('button',{name:'Open project '+project.name,exact:true}).click();await page.getByRole('button',{name:'Define',exact:true}).click();await page.getByRole('tab',{name:'Specification',exact:true}).click();await purpose().waitFor();}
 async function openPortal(kind){await railControl(kind==='access'?'Team access':'Settings');const title=kind==='access'?'Team access':team.name+' settings';const dialog=page.getByRole('dialog',{name:title,exact:true});await dialog.waitFor();await dialog.getByRole('button',{name:kind==='access'?'Close':'Back to projects',exact:true}).focus();record({kind:'actual-portal-open',portal:kind,title,viewport:page.viewportSize()});return dialog;}
 async function blockedState(){await page.getByRole('heading',{name:'Workspace unavailable',exact:true}).waitFor();return page.evaluate(({purpose,draft})=>{
  const visible=node=>!!node&&!!node.getClientRects().length&&!node.closest('[hidden],[inert]')&&getComputedStyle(node).visibility!=='hidden';
  const active=document.activeElement,entry=document.querySelector('.team-entry'),host=document.querySelector('.team-app-host');
  return {hostHidden:host?.hidden===true,privateInvisible:!document.body.innerText.includes(purpose)&&!document.body.innerText.includes(draft),noModal:![...document.querySelectorAll('[role="dialog"]')].some(visible),noPointerLock:getComputedStyle(document.body).pointerEvents!=='none',noScrollLock:!document.body.hasAttribute('data-scroll-locked'),entryAccessible:!!entry&&!entry.closest('[aria-hidden="true"],[inert]'),focusOutsidePrivate:active===document.body||visible(active)&&!active.closest('.team-app-host'),overflow:document.documentElement.scrollWidth>innerWidth};
 },{purpose:project.purpose,draft:project.draft});}
 async function captureBlocked(label){const state=await blockedState();assert(state.hostHidden&&state.privateInvisible&&state.noModal&&state.noPointerLock&&state.noScrollLock&&state.entryAccessible&&state.focusOutsidePrivate&&!state.overflow);record({kind:'blocked-modal-state',label,...state});await page.keyboard.press('Tab');const focus=await page.evaluate(()=>({visible:!!document.activeElement?.getClientRects().length,hidden:!!document.activeElement?.closest('[hidden],[inert],[aria-hidden="true"]'),inPrivate:!!document.activeElement?.closest('.team-app-host')}));assert(focus.visible&&!focus.hidden&&!focus.inPrivate);record({kind:'blocked-keyboard-focus',label,...focus});await page.screenshot({path:evidence+'/'+label+'.png'});await page.addScriptTag({content:axeSource});const axe=await page.evaluate(async()=>window.axe.run('.team-entry',{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}}));record({kind:'blocked-axe',label,violations:axe.violations.map(row=>({id:row.id,impact:row.impact,nodeCount:row.nodes.length})),passes:axe.passes.length,incomplete:axe.incomplete.length});assert.equal(axe.violations.length,0);}
 try{
  onPhase('member-sign-in');await page.goto(base,{waitUntil:'domcontentloaded'});await page.getByLabel('Username',{exact:true}).fill(member.username);await page.getByLabel('Password',{exact:true}).fill(member.password);await page.getByRole('button',{name:'Sign in',exact:true}).click();
  const entry=page.getByRole('button',{name:'Continue to projects',exact:true});await until('Account entry did not settle',async()=>await entry.isVisible()||await page.getByLabel('Workspace',{exact:true}).isVisible());if(await entry.isVisible())await entry.click();
  onPhase('workspace-and-definition-draft');await page.getByLabel('Workspace',{exact:true}).selectOption(team.id);await openProject();assert.equal(await purpose().inputValue(),project.purpose);await purpose().fill(project.draft);await until('Browser draft not retained',()=>page.getByText(/Unsaved changes · kept in this browser/).isVisible());record({kind:'actual-definition-draft',projectId:project.id,valueSHA256:sha(project.draft)});assertEmptySessions(await request('GET',sessionPath,undefined,200,member.token));
  // Team access is a real body portal. Keep it open while the real catalogue
  // receives403 and only the follow-up membership transport is fault-injected.
  onPhase('desktop-team-access-revoke');await openPortal('access');mode='abort';const first=network.length;await change('remove');await captureBlocked('1440-team-access-suspended');await until('No actual session403',()=>network.slice(first).some(row=>row.path===sessionPath&&row.status===403));
  onPhase('desktop-membership-and-draft-restore');await change('restore');await grant();await page.getByRole('button',{name:'Retry connection',exact:true}).click();const restoredAccess=page.getByRole('dialog',{name:'Team access',exact:true});await restoredAccess.waitFor();await restoredAccess.getByRole('button',{name:'Close',exact:true}).click();await purpose().waitFor();assert.equal(await purpose().inputValue(),project.draft);record({kind:'actual-portal-restored',portal:'access',draftPreserved:true});
  // Phone Team settings is a second actual portal. Evaluate privacy BEFORE
  // releasing the real missing-membership body; screenshots and axe follow.
  onPhase('phone-team-settings-open');await page.setViewportSize({width:390,height:844});await openPortal('settings');mode='hold';held=null;const before=membershipReads,start=Date.now(),focusStart=focusEvents,firstPhone=network.length;
  onPhase('phone-membership-revoke-held-body');await change('remove');await until('No actual held membership response',()=>held!==null,15000);const early=await blockedState();const witness={...early,at:Date.now(),expiresAt:held.expiresAt,released:held.released};assertHeldEarlyObservation(witness);record({kind:'early-before-membership-release',...witness});release();await until('Gate did not settle',()=>held.released);await captureBlocked('390-team-settings-suspended');
  onPhase('phone-denied-poll-episode');await until('Three actual session403 polls absent',()=>network.slice(firstPhone).filter(row=>row.path===sessionPath&&row.status===403).length>=3,20000);const episode={start:before,end:membershipReads,pollCount:network.slice(firstPhone).filter(row=>row.path===sessionPath&&row.status===403).length,focusEvents:focusEvents-focusStart,elapsedMs:Date.now()-start};assertEpisodeTraffic(episode);record({kind:'actual-denied-episode-traffic',...episode});
  onPhase('phone-membership-without-project-grant');await change('restore');await page.getByRole('button',{name:'Retry connection',exact:true}).click();await until('Restored workspace stayed blocked',async()=>!(await page.getByRole('heading',{name:'Workspace unavailable',exact:true}).isVisible()));
  // Close the legitimate workspace-only dialog BEFORE checking the project:
  // an obscuring modal must not make an old private page appear protected.
  const settings=page.getByRole('dialog',{name:team.name+' settings',exact:true});if(await settings.isVisible())await settings.getByRole('button',{name:'Back to projects',exact:true}).click();
  await request('GET',workspace+`/v1/product/projects/${project.id}/specification`,undefined,403,member.token);
  assert.equal(await purpose().isVisible(),false);const text=await page.locator('body').innerText();assert(!text.includes(project.purpose)&&!text.includes(project.draft));record({kind:'membership-restored-without-project-grant',privateProjectVisible:false,exactMemberProjectGET:403,workspaceDialogClosed:true});
  onPhase('project-grant-draft-reload-save');await grant();await page.reload({waitUntil:'domcontentloaded'});await openProject();const restore=page.getByRole('button',{name:'Restore draft',exact:true});if(await restore.isVisible())await restore.click();await purpose().waitFor();assert.equal(await purpose().inputValue(),project.draft);await page.setViewportSize({width:1440,height:1080});await page.getByRole('button',{name:'Save definition',exact:true}).click();await until('Definition save not recorded',async()=>{const saved=await request('GET',workspace+`/v1/product/projects/${project.id}/specification`,undefined,200,owner.token);return saved.purpose===project.draft;});
  onPhase('empty-session-and-final-observer-proof');assertEmptySessions(await request('GET',sessionPath,undefined,200,owner.token));await page.screenshot({path:evidence+'/1440-restored-definition.png'});record({kind:'actual-definition-saved',projectId:project.id,valueSHA256:sha(project.draft)});await background.drain();health();return {passed:true,scope:'Actual source API/browser authority and Team access/settings portal suspension; retained definition draft; zero agent sessions',membershipReads,focusEvents};
 }finally{clearTimeout(gateTimer);release?.();page.off('response',onResponse);await context.unroute(base+'/v1/teams',route);await background.drain();}
}
