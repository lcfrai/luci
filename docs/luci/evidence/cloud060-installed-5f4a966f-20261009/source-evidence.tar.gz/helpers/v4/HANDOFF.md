# CLOUD-066: CSP-preserving privileged accessibility audit

Product remains `5f4a966f6d70264c92ee2176dde912e1b43fc3c7`. V4 changes only accessibility-tool injection in the acceptance helper. No product or repository edits. V1/V2/V3 helpers, fixtures and all failed evidence remain unchanged.

V3 authored the real draft, opened Team access, received the real session-list `403 team_access_denied` after membership removal and passed the desktop blocked-modal and Tab-focus assertions. It then failed because the application's actual `script-src 'self' 'wasm-unsafe-eval'` policy rejected the inline axe script tag. These are partial positives, not a C060 acceptance pass. `evidence/v3-original-failure-projection.json` binds the original.

V4 uses standard Playwright evaluation to run the pinned axe source as a privileged audit tool. It does not change CSP response headers, set bypassCSP, add unsafe browser flags, change application allowlists or inject through a user/production pathway. Original axe scope `.team-entry`, WCAG2A/AA+2.1AA tags and zero-violation assertion remain. The controlled real-CSP proof passed in 7.28 seconds: original inline axe refused/window.axe absent, imported helper returned zero violations/nine passes/zero incomplete, later independent inline probe still refused, headers unchanged. An unlabelled-button negative produced the expected critical button-name violation. Eight selected inputs stayed unchanged; exact sources, commands, browser arguments and reports are in `validation/csp/`. Browser/listener closed with no force and no known live identities, but two sampled crashpad PID-1 zombies and unreadable environments remain literal limitations. This establishes test-tool capability, not permission for ordinary page scripts.

The remaining dialog/navigation/draft/save selectors were reviewed against current component source; `evidence/remaining-contract-review.json` records exact bindings and limits. Actual restoration, phone behavior, denied-episode traffic, regrant/save and audits remain required.

Prepare the same verified package without a compiler/npm command:

```sh
python3 /workspace/.luci-tools/cloud060-real-browser-v4/build.py \
 --repo /workspace/luci \
 --artifacts /workspace/.luci-tools/cloud060-package-reuse-v4-5f4a966f \
 --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 \
 --reuse-package-provenance /workspace/luci/artifacts/quality-swarm/candidate-5f4a966f/package/package-provenance.json \
 --isolated-checkout --window-granted
```

Root owns the fresh runtime, after review/freeze:

```sh
python3 /workspace/.luci-tools/cloud060-real-browser-v4/outer-run.py \
 --repo /workspace/luci \
 --artifacts /workspace/.luci-tools/cloud060-package-reuse-v4-5f4a966f \
 --chromium /usr/lib/chromium/chromium \
 --parent /workspace/.t/c60 \
 --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 --window-granted
```

Actual prior Playwright launch includes its default `--no-sandbox`; no browser sandbox claim is made. V3 retains two exact Chromium PID-1 zombies and 6,305 unreadable scan issues; zero known live/unknown identities does not establish complete process closure. Cleanup certification remains strict and unchanged. Docker transport remains deliberately unavailable and no agent session is allocated. Native Windows, live provider, swarm and performance gates are separate.
