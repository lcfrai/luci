# CLOUD-060 outer supervisor — runtime unexecuted

`outer-run.py` is an external Linux supervisor for `launch.mjs`. Writing this
helper does **not** verify its behavior, the application, a browser flow, cleanup,
or any performance gate. No command in this document has been executed as part
of its initial preparation. Subsequent bounded controls are scoped below;
actual application/browser execution and real pidfd cleanup remain unverified.

## Scope and command

Run only in a root-agent-approved quiet runtime window, under a non-root Linux
user. Python must support both `os.pidfd_open` and
`signal.pidfd_send_signal`. There is deliberately no PID-only signal fallback.
The caller must prepare a canonical absolute, current-user-owned private parent
directory with no group/other permissions. The supervisor creates a new
`c060-run-*` directory and never reuses or deletes an existing fixture.

After approval and prerequisite validation, the intended invocation is:

```sh
python3 /workspace/.luci-tools/cloud060-real-browser-preparation/outer-run.py \
  --repo /absolute/canonical/exact-source-checkout \
  --artifacts /absolute/canonical/matching-artifacts \
  --chromium /absolute/canonical/chromium-executable \
  --parent /absolute/canonical/private-acceptance-parent \
  --product EXACT_LOWERCASE_40_CHARACTER_PRODUCT_COMMIT \
  --window-granted
```

`--window-granted` asserts an already granted window; it does not create one.
The supervisor requires repository HEAD and the build receipt's product to match
the supplied 40-character commit. It invokes no shell and accepts no custom
executable command. `node` and `git` come from the caller's prepared PATH;
Node's resolved executable, Chromium, helper inputs and build/source members are
hashed. `NODE_OPTIONS`, provider credentials, authorization tokens, Docker
configuration and inherited application state variables are not forwarded.
The Node driver receives private `HOME`, `TMPDIR`/`TMP`/`TEMP`,
`XDG_CONFIG_HOME`, `XDG_CACHE_HOME`, `XDG_DATA_HOME` and `XDG_RUNTIME_DIR`
directories under the fresh run root. In particular, Playwright's profile
allocation through Node's `os.tmpdir()` stays under `driver-tmp`; it does not use
the user's home or global `/tmp`. These `driver-*` directories are distinct
from the driver's own application `home`/`tmp` fixture directories. The driver
must also give explicitly spawned browser/controller environments fresh paths.

The build receipt at `artifacts/build-receipt.json` must contain:

```json
{
  "product": "exact40characterlowercasegitcommitrequired",
  "passed": true,
  "sourceStable": true,
  "sourceInputs": [{"path": "relative/repository/source", "sha256": "64lowercasehex"}],
  "outputs": [{"path": "relative/artifact/output", "sha256": "64lowercasehex"}]
}
```

The example strings are explanatory placeholders, not accepted identities.
The build receipt has a separate 16 MiB read bound and is never truncated. Both
inventories must be nonempty; every declared hash is verified. Escaping,
linked, duplicate or nonregular file members are refused. These inventories
bind the declared source closure: the supervisor does not infer that an
incomplete manifest contains every compiler dependency or that HEAD implies a
clean whole checkout. The artifact producer must supply the complete build
closure and evidence. All adjacent `.mjs`, `.py` and `.md` preparation files are
also bound before and after; external imports must be present in the producer's
`sourceInputs` or separately frozen within those adjacent helpers.
The three scope-contract sources `management.go`, `runtime.go` and
`team_runtime.go` under `control-plane/internal/management/` are mandatory
members because managed child discovery follows their exact state/environment
contract.

## Driver contract

The supervisor passes the original arguments and a newly generated
`--run-root <canonical fresh private directory>`. `launch.mjs` must use exactly
that directory, not create a different run root. It must implement a 240-second
workflow deadline and at most 45 seconds of its own cleanup. Every asynchronous
startup acquisition must remain fenced after cancellation so a losing startup
continuation cannot create processes after its cleanup phase has finished.

The supervisor provides the exact environment marker
`LUCI_C060_RUN_ROOT=<run root>`. The driver must propagate that marker to every
controller, browser and detached descendant it explicitly starts. It must not
read or modify another fixture or a real Docker daemon. The marker is an
ownership selector, not a secret; the supervisor never stores process
environments, command lines or credential values.

Luci's production `isolatedEnvironment` intentionally removes that arbitrary
marker when starting a managed user/team workspace API. The driver must also
publish a private, regular, immutable-once-published
`run-root/driver-managed-scopes.json` after the real owner/member/team identities
are returned, **before any corresponding workspace-namespace request**:

```json
{
  "version": 1,
  "runRoot": "/exact/fresh/private/run-root",
  "product": "exact40characterlowercasegitcommitrequired",
  "scopes": [
    {
      "kind": "user",
      "id": "exact-user-id-from-creation",
      "stateDir": "/exact/fresh/private/run-root/state/control-plane/users/exact-user-id-from-creation/runtime/state"
    },
    {
      "kind": "team",
      "id": "exact-team-id-from-creation",
      "stateDir": "/exact/fresh/private/run-root/state/control-plane/teams/exact-team-id-from-creation/runtime/state"
    }
  ]
}
```

This illustrative file is not an accepted fixture identity. Publish all one to
three exact scopes together (normally owner, member and team); the supervisor
rejects subsequent changes, duplicate scopes, path escapes, links and unknown
kinds. IDs must match `[A-Za-z0-9_-]{1,80}` and then match the actual process
field **exactly**. No prefix wildcard or root-descendant wildcard is accepted.
The only allowed state path is the derived
`runRoot/state/control-plane/{users|teams}/{id}/runtime/state`.

For each managed-runtime match, the same-UID process must have both
`LUCI_WORKER=1` and `LUCI_MANAGED_WORKER=1`, its exact allowed `LUCI_STATE_DIR`,
and `LUCI_EXECUTION_AUTHORITY_FILE=runRoot/state/control-plane/identity.json`.
A user scope also requires the exact `LUCI_ACTOR_ID` and an absent
`LUCI_TEAM_ID`; a team scope requires its exact `LUCI_TEAM_ID` and absent
`LUCI_ACTOR_ID` **and** `LUCI_ACTOR_ROLE`. Duplicate matching-field keys are
refused. These are the production runtime fields, not arbitrary environment
substrings. The supervisor does not inspect or publish `LUCI_WORKER_TOKEN`.
It retains every discovered PID/start identity even after that process is
reparented or its environment becomes unreadable, using the same exact pidfd
signal rules as marker-owned processes. No ancestry-based catchall is used.
Its final receipt separately binds the scope ledger and records allowed scopes;
a missing/changed/unreadable scope ledger prevents a pass.

As soon as each owned process is known, the driver must atomically publish a
private regular `run-root/driver-owned-identities.json`:

```json
{
  "version": 1,
  "runRoot": "/exact/fresh/private/run-root",
  "identities": [
    {"pid": 1234, "startTicks": "12345678", "role": "controller"},
    {"pid": 1235, "startTicks": "12345679", "role": "browser"}
  ]
}
```

`startTicks` is Linux `/proc/PID/stat` field 22, represented as an integer or a
decimal string. The role is a short lowercase identifier. The ledger must be
monotonic in known identities, including exited identities. It has a maximum of
256 rows and 256 KiB. Atomically replace a complete fsynced ledger using a fresh
private temporary file and a directory fsync; do not leave partial JSON. Keep
the exact controller/browser identity even if marker scans omit it. The driver
should include its own identity. Never include the supervisor or ancestors.

The final private regular `run-root/driver-result.json` must contain:

```json
{
  "version": 1,
  "product": "exact40characterlowercasegitcommitrequired",
  "runRoot": "/exact/fresh/private/run-root",
  "passed": false,
  "cleanup": {"status": "explicit authoritative driver result"}
}
```

The driver owns the sanitized failure details, bounded fsynced JSONL events and
stage/result evidence. The outer process redirects stdout and stderr to
`/dev/null`: arbitrary child output can include credentials and is not safe to
publish by default. A syntax/preflight crash may consequently yield only an
exit status, missing-result failure and bound source rather than diagnostic
text; syntax and controlled tests must precede a runtime attempt. Driver exit
and its cleanup claim do not certify descendant closure.

## Time and cleanup budgets

| Phase | Budget | What it establishes |
| --- | ---: | --- |
| Driver workflow | 240 seconds | Driver-enforced operation deadline |
| Driver normal cleanup | 45 seconds | Driver-enforced bounded cleanup |
| Driver settlement slack | 15 seconds | Outer process waits at most 300 seconds after spawn |
| Last-resort TERM grace | 15 seconds | Exact known live identities receive TERM together |
| Post-KILL observation | 3 seconds | Bounded observation after exact forced signalling |

The driver envelope is 300 seconds, not 300 seconds followed by another
45-second driver cleanup. A deadline or interruption is recorded before any
cleanup wait. At that deadline the supervisor attempts TERM on the exact live
driver and other proven owned identities, waits no more than the TERM grace,
then uses pidfds to KILL only identities still matching their PID/start pair.
This gives a nominal maximum process-wait envelope of 318 seconds after spawn,
plus bounded-input validation/receipt work. Synchronous kernel filesystem reads
and `fsync` are not preemptible Python operations; the document makes no hard
real-time guarantee against a stalled kernel or unavailable filesystem.

Last-resort cleanup is also used if the driver exits but proven owned live
processes remain. **Any last-resort cleanup, forced signal, deadline,
interruption, missing/malformed result, changed input, known live/unknown
identity or unresolved marker scan fails this fresh acceptance attempt.**
Zombies are recorded separately and fail the strict complete-process closure
gate. They are not labelled live workers and are not signalled as live.

Signals require a current matching identity before and after pidfd acquisition.
No broad process-group signal, `pkill`, command-line substring match, Docker
cleanup, volume deletion, state deletion or reused-PID signal is used. A failed
or uncertain observation cannot authorize signalling. The known driver remains
tracked even when marker/environment scans omit it. The direct child is reaped
using nonblocking `poll()`; the supervisor cannot reap unrelated children
adopted by PID 1.

## Evidence and observation limits

The supervisor creates these exclusive original files under `run-root/supervisor`:

- `preflight.json`, `input-bindings.jsonl`, `before-launch.json` and `launched.json`.
- `events.jsonl`, fsynced for each bounded allowlisted event.
- `driver-exit-observation.json` or explicit failure/timeout/interruption evidence.
- `cleanup-entered.json` before possibly slow cleanup; optional
  `last-resort-start.json` and `before-force.json`.
- `final.json`, plus its hash/length in the final journal event and concise stdout.

Existing files are never overwritten; all original fixtures and failed evidence
remain. JSON receipts cap at 256 KiB, journal events at 64 KiB and the journal at
a fixed event count. Helper inventories cap at 64 files, source inventories at
8,192 entries each, known process identities at 256. Marker scans are bounded
by 8,192 PIDs and one cooperative second per scan; each environment read caps at
1 MiB, and only exact NUL-separated marker equality or the complete explicit
managed-scope contract above is accepted. Environment
bytes are discarded without publication. Read errors are hashed/typed or
reported as fixed codes, never printed verbatim.

Before/after identity checks guard `/proc` PID reuse during environment reads.
Processes under other UIDs are skipped as out of this nonroot fixture's scope.
Unreadable same-UID environments/identities, a scan bound, or changed identities
are explicit uncertainties; they prevent an unqualified scoped marker closure
claim. This may make a valid workflow fail the strict cleanup gate on a shared
host with unrelated unreadable same-UID processes. Resolve any such limitation
through reviewed, explicit scope evidence rather than silently treating
unreadability as absence. The result never claims whole-machine process absence.

Sampling cannot identify all short-lived children, infer zero allocations,
prove Docker/Windows/provider behavior, measure semantic output quality, or
establish responsiveness. Source hashing, scans, fsync and the supervisor itself
consume resources; no acceptance timing may subtract their cost to manufacture
a performance pass.

## Required validation before any runtime use

Preparation follow-up: Python syntax compilation passed. The exact original
bare-name receipt API produced two expected controlled errors. Correcting that
API produced five passing controls and one error in markerless environment
matching (`bytearray` keys); the original/intermediate evidence is retained.
After the exact bytes conversion, all six unchanged controls passed with stable
source bindings. They include the real exclusive/fsynced receipt API, a
no-launch preflight failure, exact markerless user/team matching, scope
negatives and fake-`/proc` identity retention. These are inert helper controls,
not actual app/browser cleanup or environment-wide closure.

Evidence is external at
`/workspace/.luci-tools/cloud060-supervisor-validation/`: original `result.json`,
corrected `followup-result.json`, frozen sources, unchanged `controlled.py` and
raw logs. `retained-no-launch/receipt.json` binds retained actual
preflight/exception/cleanup/final JSON and journal bytes from a separate
capture of the already-covered no-launch case. Its zero spawn/signal calls are
asserted; this overlapping capture is not an additional unique regression.

The initial preparation was not executed. A later requested syntax compilation
must be recorded separately and is not functional verification. Review and controlled
tests should cover at least: normal exit with exact owned closure; a driver
that never exits; stuck browser shutdown; known root omitted by marker scans;
unreadable identity after TERM; reused PID without any signal; late detached
child acquisition; child exit with a retained live browser; zombie reporting;
interruption; malformed/changed ledger; mismatched product/run root; missing
driver result; markerless exact user/team child discovery; wrong actor/team,
unknown ID, duplicate environment keys, foreign state/authority path,
scope-ledger substitution, changed/reused PID; and evidence durability when
cleanup fails. Confirm real pidfd
support under the intended nonroot runtime. Preserve original counterexamples
and source bindings, and obtain a separate runtime window before launching the
actual application/browser.
