# CLOUD-066 actual CSP audit-tool control

One actual HTTP+Chromium fixture completed in7.28seconds. The exact v4 `auditBlockedEntry` helper uses standard privileged Playwright `page.evaluate` with pinned axe4.13.0. It is test tooling, not an application CSP bypass.

The actual production default CSP literal is extracted unchanged from bound `web.go`. Original inline `addScriptTag` axe injection throws and leaves window.axe undefined. Trusted evaluation runs the same pinned source: zero violations/nine passes/zero incomplete for the labelled entry. A separate forbidden inline script after the audit still throws, never executes, and emits an enforced script-src-elem event. Fresh HTTP and second-page headers are identical. The unlabeled-button fixture reports the expected critical button-name violation.

No bypassCSP context option, header rewrite, unsafe script allowance, application allowlist change, forced click or runtime daemon was used. The recorded actual browser argv includes Playwright's default --no-sandbox: retain that limitation; it was not introduced to correct this failure. This is Chromium151.0.7922.173, not native Windows or full application acceptance.

Browser.close and owned server.close returned; a fresh connection to the fixture listener was refused with ECONNREFUSED. No forced signals occurred. Exact sampled Node and browser roots are absent. Exact crashpad PID/start identities2460587/30190566 and2460590/30190566 remain zombies. Marker scans also encountered unreadable environments; complete descendant/whole-machine absence is not proven. Preserve these literal cleanup limits.

`result.json.gz` and `owned-observations.json.gz` decode to exact original bytes; hashes are in projection.json. Original receipt/root remains at /workspace/.t/c66-cnn02iga. `source/` contains exact helpers/CSP/axe inputs; eight pre/post selected hashes were stable. stdout/stderr and actual command/cwd remain retained. Run used one browser under an80second outer deadline with bounded close/observation phases, finishing normally without reaching the deadline. No second run is credited.
