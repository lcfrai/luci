// Actual TeamWorkspaceProvider + project permissions + ReviewedContextInspector
// + WorkflowDialog + Radix. HTTP replies controlled; no browser or worker runtime.
import {useState} from 'react';
import {act,cleanup,render,screen,waitFor,within} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {afterEach,beforeEach,expect,it,vi} from 'vitest';
import {TeamWorkspaceProvider} from '/workspace/luci/desktop/src/components/teams/TeamWorkspaceProvider';
import {teamsApi,personalPermissions,type TeamSummary} from '/workspace/luci/desktop/src/api/teams';
import {api} from '/workspace/luci/desktop/src/api';
import {createClient,type SessionReviewedContext} from '/workspace/luci/desktop/src/api/client';
import {productApi} from '/workspace/luci/desktop/src/api/product';
import {teamWorkspaceStorageKey} from '/workspace/luci/desktop/src/api/teamWorkspacePreference';
import {selectTeamScope} from '/workspace/luci/desktop/src/api/teamScope';
import {resetCockpit} from '/workspace/luci/desktop/src/store/store';
import {aSession} from '/workspace/luci/desktop/src/test/fixtures';
import {ReviewedContextNote} from '/workspace/luci/desktop/src/components/develop/ReviewedContextNote';
import {useProjectAccess} from '/workspace/luci/desktop/src/hooks/useProjectAccess';
import {WorkflowDialog} from '/workspace/luci/desktop/src/components/common/WorkflowDialog';
import {hasOpenOverlay,__resetOverlays} from '/workspace/luci/desktop/src/hooks/useDismissable';
const auth=vi.hoisted(()=>({user:'portal-alice'}));
vi.mock('/workspace/luci/desktop/src/components/auth/AuthProvider',()=>({useAuth:()=>({profile:{user:{id:auth.user}},logout:vi.fn()})}));
vi.mock('/workspace/luci/desktop/src/components/setup/SetupProvider',()=>({useSetup:()=>({status:{config:{projectsDir:'/controlled/projects'},access:{user:{username:'alice'}}},workspace:{mode:'local'}})}));
const teamId='team-abcdefghijklmnopqrstuv';
const summary:TeamSummary={team:{id:teamId,name:'Controlled private team',revision:1,createdAt:'',updatedAt:''},membership:{userId:'portal-alice',role:'editor',grants:personalPermissions,revision:1},permissions:personalPermissions};
const session=aSession({id:'s-portal',projectId:'p-portal',worktreeId:'w-portal',title:'Private retained session title',implementationContext:{projectId:'p-portal',worktreeId:'w-portal',briefRevision:1,planRevision:1,specificationRevision:1,designPlanRevision:1,briefDigest:'brief',planDigest:'plan',specificationDigest:'spec',designPlanDigest:'design',taskIds:['private-task'],taskTitles:['Private retained task name'],requirementIds:[],sourceCommit:'',sourceDigest:'source',sourceDirty:false},reviewedContextDelivery:{status:'captured',version:1,digest:'a'.repeat(64)}});
const captured:SessionReviewedContext={sessionId:session.id,projectId:session.projectId,worktreeId:session.worktreeId,version:1,digest:'a'.repeat(64),implementationContext:session.implementationContext!,document:{kind:'definition',sha256:'b'.repeat(64),bytes:100,value:{purpose:'Private original captured purpose',revision:1}}};
const client=createClient({fetch:async()=>new Response(JSON.stringify({error:'team_access_denied',message:'Workspace membership unavailable'}),{status:403,headers:{'Content-Type':'application/json'}})});
const pending=<T,>()=>{let resolve!:(value:T)=>void;let reject!:(error:Error)=>void;return{promise:new Promise<T>((yes,no)=>{resolve=yes;reject=no;}),get resolve(){return resolve;},get reject(){return reject;}};};
function Surface({busy=false}:{busy?:boolean}){
 const access=useProjectAccess(session.projectId),[open,setOpen]=useState(false),[answer,setAnswer]=useState('Keep unsaved private answer');
 return <><label>Unrelated retained draft<textarea defaultValue="Keep unsaved private idea"/></label>
 <ReviewedContextNote session={session} canInspect={access.canRead} readPending={access.loading}/>
 <button onClick={()=>setOpen(true)}>Open private action review</button>
 {open&&<WorkflowDialog title="Private action review" description="Review a private task without executing it." busy={busy} onClose={()=>{if(!busy)setOpen(false);}}>
 <label>Retained answer<textarea value={answer} onChange={e=>setAnswer(e.target.value)}/></label><button disabled={busy} onClick={()=>setOpen(false)}>Close action review</button>
 </WorkflowDialog>}</>;
}
function PublicDialog(){const[open,setOpen]=useState(false);return <><button onClick={()=>setOpen(true)}>Open public recovery</button>{open&&<WorkflowDialog title="Public recovery" description="Outside the private workspace." onClose={()=>setOpen(false)}><button onClick={()=>setOpen(false)}>Close recovery</button></WorkflowDialog>}</>;}
async function open(){render(<TeamWorkspaceProvider><Surface/></TeamWorkspaceProvider>);await userEvent.click(await screen.findByRole('button',{name:'View reviewed context'}));const dialog=await screen.findByRole('dialog',{name:'Reviewed context'});await within(dialog).findByText('Private original captured purpose');expect(dialog.closest('.team-app-host')).toBeNull();expect(document.body.style.pointerEvents).toBe('none');expect(hasOpenOverlay()).toBe(true);return dialog;}
async function deny(){await act(async()=>{await client.listSessions().catch(()=>{});});}
beforeEach(()=>{auth.user='portal-alice';localStorage.clear();resetCockpit();selectTeamScope('');__resetOverlays();localStorage.setItem(teamWorkspaceStorageKey(productApi.baseUrl,auth.user),teamId);vi.spyOn(teamsApi,'list').mockResolvedValue({teams:[summary]});vi.spyOn(teamsApi,'projectAccess').mockResolvedValue({team:summary.team,projectId:session.projectId,permissions:personalPermissions,grants:[]});vi.spyOn(api,'getSessionReviewedContext').mockResolvedValue(captured);vi.spyOn(api,'listProjects').mockResolvedValue([{id:session.projectId,name:'Private project',path:'/controlled/project'}]);vi.spyOn(api,'listSessions').mockResolvedValue([session]);});
afterEach(()=>{cleanup();resetCockpit();selectTeamScope('');__resetOverlays();vi.restoreAllMocks();});
it('CLOUD-060 actual Radix portal is removed on fresh authoritative denial before membership settles',async()=>{
 await open();const held=pending<{teams:TeamSummary[]}>();vi.mocked(teamsApi.list).mockReturnValueOnce(held.promise);await deny();
 expect(document.querySelector('.team-app-host')?.hasAttribute('hidden')).toBe(true);
 expect(screen.queryByRole('dialog',{name:'Reviewed context'})).toBeNull();
 expect(screen.queryByText('Private original captured purpose')).toBeNull();
 await waitFor(()=>expect(document.body.style.pointerEvents).not.toBe('none'));
 expect(document.body.hasAttribute('data-scroll-locked')).toBe(false);expect(hasOpenOverlay()).toBe(false);
 const retry=screen.getByRole('button',{name:'Retry connection'});expect(retry.closest('[aria-hidden="true"]')).toBeNull();
 retry.focus();expect(document.activeElement).toBe(retry);await userEvent.tab();expect(document.activeElement?.closest('[hidden],[inert],[aria-hidden="true"]')).toBeNull();
 expect((document.querySelector('textarea') as HTMLTextAreaElement).value).toBe('Keep unsaved private idea');
 await act(async()=>held.reject(new Error('Controlled membership network interruption')));
 expect(screen.queryByRole('dialog')).toBeNull();
});
it('CLOUD-060 successful fresh catalogues do not automatically reopen an old private review',async()=>{
 await open();vi.mocked(teamsApi.list).mockRejectedValueOnce(new Error('Controlled network interruption'));await deny();
 await userEvent.click(screen.getByRole('button',{name:'Retry connection'}));await waitFor(()=>expect(document.querySelector('.team-app-host')?.hasAttribute('hidden')).toBe(false));
 expect(screen.queryByRole('dialog')).toBeNull();expect(api.getSessionReviewedContext).toHaveBeenCalledTimes(1);
 await userEvent.click(screen.getByRole('button',{name:'Reopen review'}));await within(await screen.findByRole('dialog',{name:'Reviewed context'})).findByText('Private original captured purpose');
 expect(api.getSessionReviewedContext).toHaveBeenCalledTimes(1);await userEvent.click(screen.getByRole('button',{name:'Close reviewed context'}));await waitFor(()=>expect(screen.queryByRole('dialog')).toBeNull());
});
it('CLOUD-060 busy private review releases modal traps without clearing its parent answer draft',async()=>{
 render(<TeamWorkspaceProvider><Surface busy/></TeamWorkspaceProvider>);await userEvent.click(await screen.findByRole('button',{name:'Open private action review'}));await userEvent.type(screen.getByRole('textbox',{name:'Retained answer'}),' amendment');
 vi.mocked(teamsApi.list).mockRejectedValueOnce(new Error('Controlled network interruption'));await deny();expect(screen.queryByRole('dialog')).toBeNull();await waitFor(()=>expect(document.body.style.pointerEvents).not.toBe('none'));
 await userEvent.click(screen.getByRole('button',{name:'Retry connection'}));await waitFor(()=>expect(document.querySelector('.team-app-host')?.hasAttribute('hidden')).toBe(false));
 expect(screen.queryByRole('dialog')).toBeNull();expect((screen.getByRole('button',{name:'Reopen review'}) as HTMLButtonElement).disabled).toBe(true);
});
it('CLOUD-060 public recovery dialog outside admitted private scope remains interactive',async()=>{
 render(<><TeamWorkspaceProvider><Surface/></TeamWorkspaceProvider><PublicDialog/></>);await screen.findByRole('button',{name:'View reviewed context'});vi.mocked(teamsApi.list).mockRejectedValueOnce(new Error('Controlled network interruption'));await deny();
 await userEvent.click(screen.getByRole('button',{name:'Open public recovery'}));await screen.findByRole('dialog',{name:'Public recovery'});await userEvent.keyboard('{Escape}');await waitFor(()=>expect(screen.queryByRole('dialog')).toBeNull());
 expect(document.body.style.pointerEvents).not.toBe('none');
});
