// Inert controlled APIs + the exact imported navigation helper. No actual app,
// browser, HTTP or Docker. Original counterexamples are extracted unchanged.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {clickRailControl,inspectRailNavigation} from './navigation.mjs';
const original=readFileSync(new URL('./validation/navigation/railControl-original.mjs',import.meta.url),'utf8');
const teamId='team-exact';
function fixture(options={}){
 const state={width:1440,expanded:true,hidden:false,teamId,hostCount:1,controls:'project-navigation',...options};
 const calls=[],rows=[];let clock=0,cancelled=false,reads=0;
 const shown=kind=>!state.hidden&&(kind!=='nav'||state.expanded),node=kind=>({
  closest:()=>state.hidden||kind==='nav'&&!state.expanded?{}:null,
  getClientRects:()=>shown(kind)?[{}]:[],getBoundingClientRect:()=>({width:kind==='nav'&&!state.expanded?0:240}),
  getAttribute:key=>key==='aria-expanded'?String(state.expanded):key==='aria-controls'?state.controls:null,
  get value(){return state.teamId;},querySelector:selector=>node(selector==='#project-navigation'?'nav':selector==='.top-projects'?'toggle':'workspace'),
 });
 const snapshot=()=>vm.runInNewContext('('+inspectRailNavigation.toString()+')()',{
  document:{querySelectorAll:selector=>{assert.equal(selector,'.team-app-host');return Array.from({length:state.hostCount},()=>node('host'));}},
  getComputedStyle:()=>({visibility:'visible'}),innerWidth:state.width,
 });
 function target(name,{bound=false,scope=teamId,toggle=false}={}){return {
  isVisible:async()=>!state.hidden&&(state.expanded||state.width===1440),
  waitFor:async({state:expected})=>{assert.equal(expected,'visible');assert(!state.hidden&&(state.expanded||state.width===1440),'controlled target remains hidden');},
  click:async opts=>{
   if(opts){assert.deepEqual(Object.keys(opts),['timeout']);assert(opts.timeout>0);}
   if(bound){assert.equal(state.teamId,scope,'exact-scope action refused');assert(!state.hidden,'hidden-host action refused');assert.equal(state.hostCount,1);}
   if(name==='Projects'){
    options.beforeDrawer?.(state);assert(!state.hidden,'Projects remains hidden');
    if(bound)assert(!state.expanded,'false-expanded selector refuses an already-open/inert toggle');
    state.expanded=!state.expanded;calls.push({action:'toggle',value:state.expanded,opts});
   }else{
    assert(state.expanded&&!state.hidden,'controlled pointer interception: collapsed/inert rail');
    calls.push({action:'select',name,teamId:state.teamId,opts});
   }
  },
 };}
 const page={
  getByRole:(_role,{name})=>target(name),
  evaluate:async fn=>{assert.equal(fn,inspectRailNavigation);reads++;if(options.neverRead)return new Promise(()=>{});options.beforeRead?.(state,reads);const value=snapshot();options.afterRead?.(state,reads);return value;},
  locator:selector=>{const match=selector.match(/option:checked\[value="([A-Za-z0-9_-]+)"\]/);assert(match,'Exact live workspace CSS binding required');const scope=match[1];return {locator:child=>{
   if(child.startsWith('.top-projects')){assert(child.includes('[aria-expanded="false"]'));return target('Projects',{bound:true,scope,toggle:true});}
   assert.equal(child,'#project-navigation:not([inert])');return {getByRole:(role,{name,exact})=>{assert.equal(role,'button');assert.equal(exact,true);return target(name,{bound:true,scope});}}};},
 };
 const health=()=>{if(cancelled)throw Error('controlled cancellation');options.onHealth?.();};
 const pause=async ms=>{clock+=ms;options.onPause?.(state,{cancel:()=>{cancelled=true;}});};
 return {state,calls,rows,page,snapshot,get reads(){return reads;},cancel:()=>{cancelled=true;},run:(extra={})=>clickRailControl({page,teamId,name:'All projects',health,record:row=>rows.push(row),timeoutMs:20,pollMs:5,now:()=>clock,pause,...extra}),old:async()=>{const fn=vm.runInNewContext('('+original+')',{page});await (await fn('All projects')).click();}};
}

test('exact original visible-only helper reproduces collapsed desktop pointer interception',async()=>{
 const f=fixture({expanded:false,width:1440});await assert.rejects(f.old,/pointer interception/);assert.equal(f.calls.length,0);
});
test('exact original helper can toggle an expanded rail closed after hidden-host restoration',async()=>{
 const f=fixture({expanded:true,width:390,hidden:true,beforeDrawer:state=>{state.hidden=false;}});await assert.rejects(f.old,/remains hidden/);assert.deepEqual(f.calls.map(x=>x.action),['toggle']);assert.equal(f.state.expanded,false);
});
for(const width of [1440,390])for(const expanded of [false,true])test(`actual corrected helper ${width} ${expanded?'expanded':'collapsed'} uses only required normal clicks`,async()=>{
 const f=fixture({width,expanded});await f.run();assert.deepEqual(f.calls.map(x=>x.action),expanded?['select']:['toggle','select']);assert.equal(f.calls.at(-1).teamId,teamId);assert.equal(f.state.expanded,true);
});
for(const width of [1440,390])test(`delayed ${width} admitted expanded host is never toggled closed`,async()=>{
 const f=fixture({width,expanded:true,hidden:true,onPause:state=>{state.hidden=false;}});await f.run();assert(f.reads>=2);assert.deepEqual(f.calls.map(x=>x.action),['select']);
});
test('a stale different workspace receives no interaction while waiting for the exact selected scope',async()=>{
 const f=fixture({teamId:'team-other',expanded:false,onPause:state=>{state.teamId=teamId;}});await f.run();assert.equal(f.rows[0].teamId,teamId);assert.deepEqual(f.calls.map(x=>x.action),['toggle','select']);
});
test('persistently wrong workspace or absent workspace fails its deadline with zero interaction',async()=>{
 for(const teamId of ['team-other',null]){const f=fixture({teamId});await assert.rejects(f.run,/navigation deadline/);assert.equal(f.calls.length,0);}
});
test('scope changed after read cannot receive the old-scope normal action',async()=>{
 const f=fixture({afterRead:(state,reads)=>{if(reads===1)state.teamId='team-other';}});await assert.rejects(f.run,/exact-scope action refused/);assert.equal(f.calls.length,0);
});
test('opening during the read-to-click gap cannot close an already-expanded drawer',async()=>{
 const f=fixture({expanded:false,afterRead:state=>{state.expanded=true;}});await assert.rejects(f.run,/already-open/);assert.equal(f.calls.length,0);assert.equal(f.state.expanded,true);
});
test('already-cancelled navigation starts no DOM read or interaction',async()=>{
 const f=fixture();f.cancel();await assert.rejects(f.run,/cancellation/);assert.equal(f.reads,0);assert.equal(f.calls.length,0);
});
test('cancellation while waiting for workspace readiness cannot make a later click',async()=>{
 const f=fixture({hidden:true,onPause:(state,{cancel})=>{state.hidden=false;cancel();}});await assert.rejects(f.run,/cancellation/);assert.equal(f.calls.length,0);
});
test('cancelled health after DOM observation fences both possible actions',async()=>{
 for(const expanded of [false,true]){const f=fixture({expanded,afterRead:()=>f.cancel()});await assert.rejects(f.run,/cancellation/);assert.equal(f.calls.length,0);}
});
test('never-settling read reaches the explicit observation deadline without clicking',async()=>{
 const f=fixture({neverRead:true});await assert.rejects(f.run,/observation deadline/);assert.equal(f.calls.length,0);
});
test('hidden host and ambiguous host count exhaust the bounded wait with no navigation',async()=>{
 for(const patch of [{hidden:true},{hostCount:0},{hostCount:2}]){const f=fixture(patch);await assert.rejects(f.run,/navigation deadline/);assert.equal(f.calls.length,0);}
});
test('invalid expansion/controls fails rather than guessing from target visibility',async()=>{
 const f=fixture({controls:'other-navigation'});await assert.rejects(f.run,/actual rail/);assert.equal(f.calls.length,0);
});
