import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
const root=new URL('./',import.meta.url),literal=readFileSync(new URL('injected-source.literal.js',root),'utf8');
const source=vm.runInNewContext('('+literal+')',{}, {timeout:1000});
if(typeof source!=='string'||!source.includes('var InjectedScript = class'))throw Error('Unexpected pinned injected source');
writeFileSync(new URL('pinned-injected.cjs',root),source);
console.log(JSON.stringify({bytes:Buffer.byteLength(source),sha256:createHash('sha256').update(source).digest('hex')}));
