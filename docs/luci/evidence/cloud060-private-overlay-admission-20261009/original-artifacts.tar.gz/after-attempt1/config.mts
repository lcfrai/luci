import {defineConfig} from '/workspace/luci/desktop/node_modules/vitest/dist/config.js';
import react from '/workspace/luci/desktop/node_modules/@vitejs/plugin-react/dist/index.js';
import fs from 'node:fs';
const root='/workspace/luci/desktop',stage='/workspace/.luci-tools/cloud060-workspace-portals';
const paths=['src/components/common/WorkflowDialog.tsx','src/components/common/WorkspaceOverlayScope.tsx','src/components/teams/TeamWorkspaceProvider.tsx','src/hooks/useDismissable.ts'];
export default defineConfig({root,plugins:[{name:'cloud060-overlay',enforce:'pre',resolveId(source,importer){if(process.env.CLOUD060_FIXED==='1'&&source.endsWith('/WorkspaceOverlayScope'))return root+'/src/components/common/WorkspaceOverlayScope.tsx';},load(id){const path=id.split('?')[0];if(process.env.CLOUD060_FIXED==='1'&&paths.some(p=>path===root+'/'+p))return fs.readFileSync(stage+'/after/desktop/'+path.slice(root.length+1),'utf8');}},react()],server:{fs:{allow:['/workspace/luci',stage]}},test:{environment:'jsdom',include:[stage+'/authority-portals.test.tsx'],setupFiles:[root+'/src/test/setup.ts'],globals:false,restoreMocks:true,clearMocks:true,maxWorkers:1}});
