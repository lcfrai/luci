const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const ts=require('/workspace/luci/desktop/node_modules/typescript');
const repo='/workspace/luci/desktop',stage=__dirname;
const config=ts.readConfigFile(path.join(repo,'tsconfig.json'),ts.sys.readFile);
const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,repo);
const host=ts.createCompilerHost(parsed.options), originalRead=host.readFile,originalExists=host.fileExists;
const seen=new Map();
function overlay(file){const rel=path.relative(repo,file);return !rel.startsWith('..')?path.join(stage,'after/desktop',rel):'';}
host.fileExists=file=>{const p=overlay(file);return !!p&&fs.existsSync(p)||originalExists(file);};
host.readFile=file=>{const p=overlay(file);const chosen=p&&fs.existsSync(p)?p:file;const data=originalRead(chosen);if(data!==undefined)seen.set(file,{path:file,source:chosen,bytes:Buffer.byteLength(data),sha256:crypto.createHash('sha256').update(data).digest('hex')});return data;};
const prog=ts.createProgram([...parsed.fileNames,stage+'/authority-portals.test.tsx'],parsed.options,host);
const diagnostics=ts.getPreEmitDiagnostics(prog);
fs.writeFileSync(process.env.CLOUD060_TS_BINDINGS||stage+'/typecheck-bindings.json',JSON.stringify([...seen.values()],null,2)+'\n');
console.log(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCurrentDirectory:()=>repo,getCanonicalFileName:x=>x,getNewLine:()=>"\n"}));
console.log(JSON.stringify({diagnostics:diagnostics.length,inputs:seen.size}));process.exitCode=diagnostics.length?2:0;
