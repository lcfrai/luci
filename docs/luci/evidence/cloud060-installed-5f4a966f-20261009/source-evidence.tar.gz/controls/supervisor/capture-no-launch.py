#!/usr/bin/env python3
"""Retain actual inert preflight-failure files; overlaps one passing unit case."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import pathlib
import types
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = ROOT.parent / "cloud060-real-browser-preparation/outer-run.py"
OUT = ROOT / "retained-no-launch"
OUT.mkdir(mode=0o700)
source_before = SOURCE.read_bytes()
spec = importlib.util.spec_from_file_location("c060_retained_supervisor", SOURCE)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
paths = {key: OUT / key for key in ("repo", "artifacts", "parent")}
for path in paths.values():
    path.mkdir(mode=0o700)
executable = OUT / "inert-executable"
executable.write_text("Never executed; fake prerequisite for preflight failure.\n")
executable.chmod(0o700)
args = types.SimpleNamespace(**{key: str(path) for key, path in paths.items()},
    chromium=str(executable), product="a" * 40, window_granted=True)
scan = {"at": "controlled", "matched": [], "issues": [], "issueCount": 0,
    "scanned": 0, "otherUIDSkipped": 0, "complete": True,
    "managedScopeLedger": {"status": "absent"}}
with (mock.patch.object(m, "git_head", return_value="b" * 40),
      mock.patch.object(m.shutil, "which", return_value=str(executable)),
      mock.patch.object(m.Ownership, "scan", return_value=scan),
      mock.patch.object(m.subprocess, "Popen", side_effect=AssertionError("No child allowed")) as spawn,
      mock.patch.object(m.signal, "pidfd_send_signal", side_effect=AssertionError("No signal allowed")) as signals,
      contextlib.redirect_stdout(io.StringIO()) as stdout):
    status = m.run(args)
assert status == 1 and spawn.call_count == 0 and signals.call_count == 0
run_root, = paths["parent"].iterdir()
for name in ("preflight", "exception", "cleanup-entered", "final"):
    assert (run_root / "supervisor" / (name + ".json")).is_file()
final = json.loads((run_root / "supervisor/final.json").read_bytes())
assert final["passed"] is False and final["runtimeExecuted"] is False
assert "supervisor-exception" in final["reasons"]
assert SOURCE.read_bytes() == source_before
receipt = {"version": 1, "passed": True, "overlaps": "test_no_launch_preflight_failure_persists_exception_cleanup_and_final",
    "scope": "Temporary fake prerequisites and observations; actual fsynced supervisor receipts; no child launch or signals",
    "root": str(run_root), "source": {"path": str(SOURCE), "sha256": hashlib.sha256(source_before).hexdigest()},
    "scriptSHA256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    "sourceStable": True, "expectedFailureExit": status, "spawnCalls": spawn.call_count,
    "signalCalls": signals.call_count, "stdout": json.loads(stdout.getvalue()),
    "artifacts": [{"path": str(p.relative_to(OUT)), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                   "bytes": p.stat().st_size} for p in sorted(OUT.rglob("*")) if p.is_file()]}
with (OUT / "receipt.json").open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
    stream.flush()
    os.fsync(stream.fileno())
print(json.dumps({"passed": True, "receipt": str(OUT / "receipt.json"),
                  "sourceStable": True, "spawnCalls": 0, "signalCalls": 0}))
