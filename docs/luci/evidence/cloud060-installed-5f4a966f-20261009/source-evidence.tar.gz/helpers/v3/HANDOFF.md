# CLOUD-064: exact semantic purpose selector

Product remains `5f4a966f6d70264c92ee2176dde912e1b43fc3c7`. V3 changes only the acceptance helper's purpose locator; no product or repository changes. Actual V3 browser execution remains pending. Original V1 and V2 helpers and every failed fixture remain unchanged.

CLOUD-061 is the original long Unix-socket fixture path. CLOUD-062 fixes rail navigation using current exact workspace readiness and Projects `aria-expanded`. The actual V2 run passed its expanded-desktop rail selection and reached Specification, then timed out waiting for `getByLabel('The idea', {exact:true})`. The retained screenshot shows the correct purpose textarea. `evidence/v2-original-failure-projection.json` binds that original failure and separate cleanup evidence; it does not invent missing DOM or accessible-name observations.

CLOUD-064 reproduces that label query against the pinned Playwright selector engine and actual DefinitionWorkspace: for the nonempty fixture, internal-label computes `The ideaSaved owner-a p-alpha purpose` and exact `The idea` matches zero; the exact semantic textbox engine matches the one intended field. The empty-purpose control matches both engines. This establishes the helper mismatch without changing the product label. V3 selects the exact semantic textbox named `The idea`, within the admitted current team host and exact selected project. It still asserts the authored purpose before editing, the exact retained draft after restoration, denied visibility without a project grant, and the actual saved value afterward. There is no forced click, selector by value, direct application mutation, weaker privacy oracle or automatic save.

Six controlled tests pass using the actual imported V3 helper, real DefinitionWorkspace, mocked API/provider boundaries and the unchanged pinned Playwright internal-label/internal-role engines. They cover nonempty/empty purpose, explicit editing/saving, wrong team/project, hidden host, unselected project, actor/project draft separation and malformed selector identifiers. These are component/selector controls, not real browser/API acceptance. The unsupported `--minWorkers` attempt failed before test loading and is retained separately. Final test, source/extraction, command, logs and input hashes are under `validation/purpose/`. Rail logic, lifecycle/cleanup, privacy, focus, consent and mutation assertions are unchanged from V2. The original fixtures have no C060 authority-revocation pass.

Package reuse verifies the same original archive, extracted selected binary/web files and new copied bytes without any npm/compiler command:

```sh
python3 /workspace/.luci-tools/cloud060-real-browser-v3/build.py \
  --repo /workspace/luci \
  --artifacts /workspace/.luci-tools/cloud060-package-reuse-v3-5f4a966f \
  --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 \
  --reuse-package-provenance /workspace/luci/artifacts/quality-swarm/candidate-5f4a966f/package/package-provenance.json \
  --isolated-checkout --window-granted
```

Root owns the actual runtime launch, after helper/source review and package binding. Use the existing short private parent; outer creates a fresh child and never reuses prior application state:

```sh
python3 /workspace/.luci-tools/cloud060-real-browser-v3/outer-run.py \
  --repo /workspace/luci \
  --artifacts /workspace/.luci-tools/cloud060-package-reuse-v3-5f4a966f \
  --chromium /usr/lib/chromium/chromium \
  --parent /workspace/.t/c60 \
  --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 --window-granted
```

The actual previous Playwright launch included `--no-sandbox`; no browser sandbox claim is made. The V2 final receipt retains two exact owned PID-1 Chromium zombies and 6,272 unreadable environment scan issues despite zero known live/unknown identities. Known identity absence is not wholehost scan completeness. Cleanup certification is unchanged and neither uncertainty nor zombies are waived. This is API/web browser acceptance only, with deliberately unavailable Docker transport and zero agent sessions; native Windows, live provider, swarm and responsiveness gates remain separate.
