import { Activity, useEffect, useRef, useState, type ReactNode } from "react";
import { useDismissable } from "../../hooks/useDismissable";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../fluid/components/dialog";
import { Button } from "../fluid/components/button";
import { useWorkspaceOverlayAvailable } from "./WorkspaceOverlayScope";
import "./workflow-dialog.css";

type WorkflowDialogProps = {
  title: string; description: string; busy?: boolean; onClose(): void; children: ReactNode;
  getCloseFocusTarget?(openingControl: HTMLElement | null): HTMLElement | null;
};

/** Retain modal-owned drafts while disconnected workspace access suspends presentation. */
export function WorkflowDialog(props: WorkflowDialogProps) {
  const available = useWorkspaceOverlayAvailable();
  const latestAvailable = useRef(available); latestAvailable.current = available;
  const [returnFocusTo] = useState<HTMLElement | null>(() =>
    typeof document !== "undefined" && document.activeElement instanceof HTMLElement ? document.activeElement : null,
  );
  const [paused, setPaused] = useState(false);
  if (!available && !paused) setPaused(true);
  const visible = available && !paused;
  const usableTrigger = returnFocusTo?.isConnected && returnFocusTo !== document.body &&
    !returnFocusTo.closest("[hidden], [inert]");
  useEffect(() => {
    if (!available || !paused || !returnFocusTo || !usableTrigger) return;
    const reopen = () => { if (latestAvailable.current) setPaused(false); };
    // A deliberate click on the existing opening control resumes this retained
    // review. Fresh authority alone never makes old private portal content visible.
    returnFocusTo.addEventListener("click", reopen);
    return () => returnFocusTo.removeEventListener("click", reopen);
  }, [available, paused, returnFocusTo, usableTrigger]);
  return <>
    {available && paused && !usableTrigger && <Button type="button" variant="secondary" onClick={() => setPaused(false)}>Resume paused dialog</Button>}
    <Activity mode={visible ? "visible" : "hidden"}>
      <WorkflowDialogModal {...props} returnFocusTo={returnFocusTo} mayRestoreFocus={() => latestAvailable.current && !paused} />
    </Activity>
  </>;
}

function WorkflowDialogModal({ title, description, busy = false, onClose, getCloseFocusTarget, children, returnFocusTo, mayRestoreFocus }: WorkflowDialogProps & {
  returnFocusTo: HTMLElement | null; mayRestoreFocus(): boolean;
}) {
  const panel = useDismissable<HTMLDivElement>(true, () => { if (!busy) onClose(); }, false);
  const restore = useRef(mayRestoreFocus); restore.current = mayRestoreFocus;
  return <Dialog open onOpenChange={open => { if (!open && !busy) onClose(); }}>
    <DialogContent ref={panel} size="lg" showCloseButton={false} aria-modal="true"
      onCloseAutoFocus={event => {
        event.preventDefault();
        if (!restore.current()) return;
        const target = getCloseFocusTarget ? getCloseFocusTarget(returnFocusTo) : returnFocusTo;
        if (target?.isConnected && !target.closest("[hidden], [inert]")) target.focus();
      }}
      onEscapeKeyDown={event => { if (busy) event.preventDefault(); }}
      onPointerDownOutside={event => { if (busy) event.preventDefault(); }}>
      <DialogHeader><DialogTitle>{title}</DialogTitle><DialogDescription>{description}</DialogDescription></DialogHeader>
      {children}
    </DialogContent>
  </Dialog>;
}
