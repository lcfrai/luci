import assert from 'node:assert/strict';
export const budgets={workflowMs:240000,cleanupMs:45000,httpMs:10000,gateMs:8000,bodyBytes:2*1024**2,maxRequests:2048,maxJournalBytes:4*1024**2,maxEventBytes:8192};
export const emptyGrants={execute:false,secrets:false,deploy:false,admin:false};
export function validateProduct(value){assert.match(value??'',/^[a-f0-9]{40}$/,'An immutable final product revision is required');return value;}
export function browserRequestAllowed({method,url,origin,teamId,projectId}) {
 const u=new URL(url);if(u.origin!==origin||u.username||u.password||u.hash)return false;
 if(['GET','HEAD','OPTIONS'].includes(method))return true;
 if(method==='POST'&&u.pathname==='/v1/auth/login'&&!u.search)return true;
 return method==='POST'&&!!teamId&&!!projectId&&!u.search&&u.pathname===`/v1/teams/${teamId}/workspace/v1/product/projects/${projectId}/specification`;
}
/** Operator authority setup is explicit. No broad '/v1/' mutation allowance. */
export function operatorRequestAllowed({method,path,teamId,projectId,memberId}){
 const u=new URL(path,'http://fixture.invalid');if(u.origin!=='http://fixture.invalid'||u.hash||u.search||u.pathname!==path)return false;
 if(method==='GET')return path==='/v1/control-plane/status'||path==='/v1/auth/me'||path==='/v1/teams'||!!teamId&&[ `/v1/teams/${teamId}`,`/v1/teams/${teamId}/workspace/v1/sessions`,`/v1/teams/${teamId}/workspace/v1/projects`, ...(projectId?[`/v1/teams/${teamId}/workspace/v1/product/projects/${projectId}/specification`]:[])].includes(path);
 if(method==='POST'&&['/v1/auth/bootstrap','/v1/auth/login','/v1/admin/users','/v1/teams'].includes(path))return true;
 if(!teamId)return false;
 if(method==='POST'&&[`/v1/teams/${teamId}/members`,`/v1/teams/${teamId}/workspace/v1/setup/git/identity`,`/v1/teams/${teamId}/workspace/v1/product/projects`].includes(path))return true;
 if(method==='DELETE'&&memberId&&path===`/v1/teams/${teamId}/members/${memberId}`)return true;
 if(method==='PUT'&&projectId&&memberId&&path===`/v1/teams/${teamId}/projects/${projectId}/members/${memberId}`)return true;
 return method==='POST'&&projectId&&path===`/v1/teams/${teamId}/workspace/v1/product/projects/${projectId}/specification`;
}
export function assertEmptySessions(value){assert(value&&Array.isArray(value.sessions));assert.equal(value.sessions.length,0,'No actual or manufactured agent session is allowed');}
export function denialProjection(status,bytes){assert.equal(status,403);const value=JSON.parse(bytes);assert.equal(value.error,'team_access_denied');return {status,code:value.error,bytes:Buffer.byteLength(bytes)};}
export function assertEpisodeTraffic({start,end,pollCount,focusEvents,elapsedMs}){assert.equal(focusEvents,0,'Focus refresh confounds episode count');assert(elapsedMs<45000,'Periodic refresh confounds episode count');assert(pollCount>=3,'Three actual empty-session denials required');assert.equal(end-start,1,'Denied episode must not repeatedly refresh membership');}
export function sameIdentity(saved,current){return !!current&&saved.pid===current.pid&&String(saved.startTicks??saved.start)===String(current.startTicks??current.start);}
export function assertHeldEarlyObservation(value){assert(value&&!value.released&&value.at<value.expiresAt,'Early privacy observation must finish before response gate releases');assert(value.privateInvisible&&value.noModal&&value.noPointerLock&&value.noScrollLock&&value.focusOutsidePrivate,'Early modal privacy/interaction observation failed');}

export function managedScopeMatches(env,scopes,runRoot){
 const values=new Map();for(const entry of env){const split=entry.indexOf('=');if(split<1)continue;const key=entry.slice(0,split);if(values.has(key))return false;values.set(key,entry.slice(split+1));}
 if(values.get('LUCI_MANAGED_WORKER')!=='1'||values.get('LUCI_WORKER')!=='1'||values.get('LUCI_EXECUTION_AUTHORITY_FILE')!==runRoot+'/state/control-plane/identity.json')return false;
 return scopes.some(scope=>values.get('LUCI_STATE_DIR')===scope.stateDir&&(scope.kind==='user'?values.get('LUCI_ACTOR_ID')===scope.id&&!values.has('LUCI_TEAM_ID'):values.get('LUCI_TEAM_ID')===scope.id&&!values.has('LUCI_ACTOR_ID')&&!values.has('LUCI_ACTOR_ROLE')));
}
