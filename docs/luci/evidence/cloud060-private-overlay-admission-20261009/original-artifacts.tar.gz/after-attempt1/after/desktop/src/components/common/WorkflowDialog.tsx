import { useRef, useState, type ReactNode } from "react";
import { useDismissable } from "../../hooks/useDismissable";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../fluid/components/dialog";
import { Button } from "../fluid/components/button";
import { useWorkspaceOverlayAvailable } from "./WorkspaceOverlayScope";
import "./workflow-dialog.css";

/** The shadcn/Radix modal supplies focus trapping; the shared overlay stack owns app shortcuts. */
export function WorkflowDialog({ title, description, busy = false, onClose, getCloseFocusTarget, children }: {
  title: string; description: string; busy?: boolean; onClose(): void; children: ReactNode;
  /** Resolve a guarded destination after the modal focus trap is removed; null skips restoration. */
  getCloseFocusTarget?(openingControl: HTMLElement | null): HTMLElement | null;
}) {
  const [returnFocusTo, setReturnFocusTo] = useState<HTMLElement | null>(() =>
    typeof document !== "undefined" && document.activeElement instanceof HTMLElement ? document.activeElement : null,
  );
  const available = useWorkspaceOverlayAvailable();
  const currentAvailability = useRef(available); currentAvailability.current = available;
  const [paused, setPaused] = useState(false);
  // A portal escapes the hidden workspace DOM. Remove the real modal and its
  // global focus/pointer/scroll effects without asking the owner to discard a
  // draft or pretending an in-flight operation was cancelled.
  if (!available && !paused) setPaused(true);
  const visible = available && !paused;
  // Radix owns focus restoration here; the overlay stack must not focus the
  // old private trigger while its workspace is hidden.
  const panel = useDismissable<HTMLDivElement>(visible, () => { if (!busy) onClose(); }, false);
  if (!available) return null;
  if (paused) return <section className="workflow-paused-review" aria-label="Paused review">
    <p role="status">This review was paused when workspace access changed. Your unsaved edits are kept. Reopen it to check the current context before continuing.</p>
    <Button type="button" variant="secondary" disabled={busy} onClick={() => {
      setReturnFocusTo(document.activeElement instanceof HTMLElement ? document.activeElement : null);
      setPaused(false);
    }}>Reopen review</Button>
  </section>;
  return <Dialog open onOpenChange={open => { if (!open && !busy) onClose(); }}>
    <DialogContent ref={panel} size="lg" showCloseButton={false} aria-modal="true"
      onCloseAutoFocus={event => {
        // This controlled dialog has no Radix Trigger. Restore the opening
        // control after its focus trap is removed, rather than during cleanup.
        event.preventDefault();
        if (!currentAvailability.current) return;
        const target = getCloseFocusTarget ? getCloseFocusTarget(returnFocusTo) : returnFocusTo;
        if (target?.isConnected && !target.closest("[hidden], [inert]")) target.focus();
      }}
      onEscapeKeyDown={event => { if (busy) event.preventDefault(); }}
      onPointerDownOutside={event => { if (busy) event.preventDefault(); }}>
      <DialogHeader><DialogTitle>{title}</DialogTitle><DialogDescription>{description}</DialogDescription></DialogHeader>
      {children}
    </DialogContent>
  </Dialog>;
}
