// PREPARED, NOT EXECUTED: pure guard tests; no server/browser/daemon activity.
import test from 'node:test';
import assert from 'node:assert/strict';
import {browserRequestAllowed,assertEmptySessions,denialProjection,assertEpisodeTraffic} from './guards.mjs';
const scope={origin:'http://127.0.0.1:19730',teamId:'team-fixture',projectId:'p-fixture'};
test('same-origin read and exact definition save only',()=>{
 assert(browserRequestAllowed({...scope,method:'GET',url:scope.origin+'/v1/teams'}));
 assert(browserRequestAllowed({...scope,method:'POST',url:scope.origin+'/v1/auth/login'}));
 assert(browserRequestAllowed({...scope,method:'POST',url:scope.origin+'/v1/teams/team-fixture/workspace/v1/product/projects/p-fixture/specification'}));
 for(const suffix of ['/v1/sessions','/v1/setup/runtime/install','/v1/teams/team-fixture/workspace/v1/sessions','/v1/teams/team-other/workspace/v1/product/projects/p-fixture/specification','/v1/teams/team-fixture/workspace/v1/product/projects/p-other/specification'])assert(!browserRequestAllowed({...scope,method:'POST',url:scope.origin+suffix}));
 assert(!browserRequestAllowed({...scope,method:'GET',url:'https://unrelated.invalid/v1/teams'}));
 assert(!browserRequestAllowed({...scope,method:'DELETE',url:scope.origin+'/v1/sessions/s-one'}));
});
test('empty catalogue only, no fixture worker manufacture',()=>{assertEmptySessions({sessions:[]});assert.throws(()=>assertEmptySessions({sessions:[{id:'s-one'}]}));assert.throws(()=>assertEmptySessions({}));});
test('actual typed membership denial distinct from generic403/network',()=>{assert.equal(denialProjection(403,'{"error":"team_access_denied"}').code,'team_access_denied');for(const [status,body] of [[200,'{"error":"team_access_denied"}'],[403,'{"error":"permission_denied"}'],[401,'{}']])assert.throws(()=>denialProjection(status,body));});
test('episode observations cannot pass with absent polls, focus, periodic or extra reads',()=>{const row={start:2,end:3,pollCount:3,focusEvents:0,elapsedMs:7000};assertEpisodeTraffic(row);for(const patch of [{end:4},{pollCount:2},{focusEvents:1},{elapsedMs:61000}])assert.throws(()=>assertEpisodeTraffic({...row,...patch}));});

import {operatorRequestAllowed,validateProduct,sameIdentity,assertHeldEarlyObservation} from './guards.mjs';
import {createBackgroundFence} from './capture.mjs';
test('final product is immutable, never a branch or incomplete prefix',()=>{assert.equal(validateProduct('a'.repeat(40)),'a'.repeat(40));for(const value of ['',undefined,'main','a'.repeat(39),'A'.repeat(40)])assert.throws(()=>validateProduct(value));});
test('operator permits only exact fixture authority/context mutations, never a worker or model',()=>{
 const scope={teamId:'team-one',memberId:'user-one',projectId:'p-one'};
 for(const [method,path] of [['POST','/v1/auth/bootstrap'],['POST','/v1/admin/users'],['POST','/v1/teams'],['DELETE','/v1/teams/team-one/members/user-one'],['PUT','/v1/teams/team-one/projects/p-one/members/user-one'],['POST','/v1/teams/team-one/workspace/v1/product/projects/p-one/specification'],['GET','/v1/teams/team-one/workspace/v1/sessions']])assert(operatorRequestAllowed({...scope,method,path}));
 for(const [method,path] of [['DELETE','/v1/teams/team-other/members/user-one'],['DELETE','/v1/teams/team-one/members/user-other'],['PUT','/v1/teams/team-one/projects/p-other/members/user-one'],['POST','/v1/teams/team-one/workspace/v1/sessions'],['POST','/v1/teams/team-one/workspace/v1/product/projects/p-one/checks'],['POST','/v1/setup/runtime/install'],['POST','/v1/teams/team-one/workspace/v1/setup/agents'],['GET','/v1/teams/team-one/workspace/v1/sessions#ignored'],['POST','/v1/teams/team-one/workspace/v1/product/projects/p-one/specification?x=1']])assert(!operatorRequestAllowed({...scope,method,path}),path);
});
test('same PID with a replaced start identity is never this fixture allocation',()=>{assert(sameIdentity({pid:42,start:'13'},{pid:42,startTicks:13}));assert(!sameIdentity({pid:42,start:'13'},{pid:42,start:'14'}));assert(!sameIdentity({pid:42,start:'13'},null));});
test('early privacy witness cannot credit observations made after releasing or expiring real response gate',()=>{
 const good={released:false,at:100,expiresAt:200,privateInvisible:true,noModal:true,noPointerLock:true,noScrollLock:true,focusOutsidePrivate:true};assertHeldEarlyObservation(good);
 for(const patch of [{released:true},{at:200},{privateInvisible:false},{noModal:false},{noPointerLock:false},{noScrollLock:false},{focusOutsidePrivate:false}])assert.throws(()=>assertHeldEarlyObservation({...good,...patch}));
});
test('an asynchronous response observer failure reaches the workflow and drain, never only a log',async()=>{
 const original=new Error('controlled-observer-failure'),failures=[];const fence=createBackgroundFence(error=>failures.push(error));
 fence.track(async()=>{throw original;});await new Promise(resolve=>setImmediate(resolve));
 assert.deepEqual(failures,[original]);assert.throws(()=>fence.check(),error=>error===original);await assert.rejects(()=>fence.drain(),error=>error===original);
});
test('pending successful response observer remains in the explicit drain barrier',async()=>{
 let release;const failures=[],fence=createBackgroundFence(error=>failures.push(error));fence.track(()=>new Promise(resolve=>{release=resolve;}));await new Promise(resolve=>setImmediate(resolve));assert.equal(fence.size,1);let done=false;const drain=fence.drain().then(()=>{done=true;});await Promise.resolve();assert.equal(done,false);release();await drain;assert.equal(done,true);assert.deepEqual(failures,[]);
});

import {controllerExitObserver} from './capture.mjs';
import {managedScopeMatches} from './guards.mjs';
test('owned controller exit poisons active workflow but normal cleanup exit does not',()=>{
 let closing=false;const failures=[],events=[];const observe=controllerExitObserver({isClosing:()=>closing,record:row=>events.push(row),fail:error=>failures.push(error)});observe(0,null);assert.equal(failures.length,1);assert.equal(failures[0].code,'controller-exited');closing=true;observe(0,null);assert.equal(failures.length,1);assert.equal(events.length,2);
});
test('controller exit recording failure cannot become an unnoticed workflow success',()=>{const failure=Error('journal full'),failures=[];controllerExitObserver({isClosing:()=>true,record:()=>{throw failure;},fail:error=>failures.push(error)})(0,null);assert.deepEqual(failures,[failure]);});
test('unmarked managed workers require exact published namespace, owner and authority path',()=>{
 const root='/private/fixture',scopes=[{kind:'user',id:'u-one',stateDir:root+'/state/control-plane/users/u-one/runtime/state'},{kind:'team',id:'team-one',stateDir:root+'/state/control-plane/teams/team-one/runtime/state'}];
 const common=['LUCI_WORKER=1','LUCI_MANAGED_WORKER=1','LUCI_EXECUTION_AUTHORITY_FILE='+root+'/state/control-plane/identity.json'];
 const user=[...common,'LUCI_ACTOR_ID=u-one','LUCI_STATE_DIR='+scopes[0].stateDir],team=[...common,'LUCI_TEAM_ID=team-one','LUCI_STATE_DIR='+scopes[1].stateDir];assert(managedScopeMatches(user,scopes,root));assert(managedScopeMatches(team,scopes,root));
 for(const env of [[...team,'LUCI_ACTOR_ROLE=member'],[...team,'LUCI_ACTOR_ID=u-one'],[...user,'LUCI_TEAM_ID=team-one'],user.map(x=>x.replace('u-one','u-other')),team.map(x=>x.replace('team-one','team-other')),team.map(x=>x.replace('/private/fixture','/other/fixture')),team.map(x=>x.replace('LUCI_WORKER=1','LUCI_WORKER=0')),[...team,'LUCI_STATE_DIR='+scopes[1].stateDir]])assert(!managedScopeMatches(env,scopes,root));
});
