import { createContext, useContext } from "react";

/** Only admitted workspace children inherit this display boundary. Account,
 * invitation and blocked-workspace recovery controls remain outside it. */
const WorkspaceOverlayContext = createContext(true);
export const WorkspaceOverlayScope = WorkspaceOverlayContext.Provider;
export const useWorkspaceOverlayAvailable = () => useContext(WorkspaceOverlayContext);
