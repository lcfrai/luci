from pathlib import Path
import hashlib,json,subprocess
repo=Path('/workspace/luci'); root=Path('/workspace/.luci-tools/cloud060-workspace-portals')
out=root/'after-owner-calls'; before=root/'before-owner-calls'
changed={}
def edit(path, fn):
 p=repo/path; raw=p.read_bytes(); src=raw.decode(); dst=fn(src)
 assert dst!=src,path
 target=out/path; target.parent.mkdir(parents=True,exist_ok=True);target.write_text(dst)
 original=before/path;original.parent.mkdir(parents=True,exist_ok=True);original.write_bytes(raw)
 changed[path]={'beforeSHA256':hashlib.sha256(raw).hexdigest(),'afterSHA256':hashlib.sha256(target.read_bytes()).hexdigest()}
def replace(src,old,new,count=1):
 assert src.count(old)==count,(old,src.count(old),count)
 return src.replace(old,new)
base='desktop/src/components/'
for file,access,n in [('journey/ProjectRuns.tsx','access',1),('journey/ProjectSwarm.tsx','projectAccess',4),('journey/ContextStorage.tsx','access',1),('lens/DeployLens.tsx','projectAccess',1),('orchestrator/OrchestratorPanel.tsx','access',1)]:
 edit(base+file,lambda s,a=access,n=n: replace(s,'<WorkflowDialog ',f'<WorkflowDialog readAccess={{{a}}} ',n))
for file in ['journey/SwarmWorkspaceReview.tsx','journey/SwarmTaskHandoff.tsx']:
 edit(base+file,lambda s: replace(s,'<WorkflowDialog ','<WorkflowDialog readAccess={{...access, canRead}} '))
# Exact branch target, never current selected project.
edit(base+'journey/BranchManager.tsx',lambda s: replace(replace(replace(s,'import { WorkflowDialog }','import { useProjectAccess } from "../../hooks/useProjectAccess";\nimport { WorkflowDialog }'),'  const { projectId, action } = target;','  const { projectId, action } = target;\n  const readAccess = useProjectAccess(projectId);'),'<WorkflowDialog ','<WorkflowDialog readAccess={readAccess} '))
# Forward access already owned above each child dialog. Required props avoid accidental production fallback.
for file in ['journey/SwarmCheckpointDialog.tsx','journey/SwarmLaunchRecoveryDialog.tsx','journey/CheckRecoveryDialog.tsx','orchestrator/AmendmentReview.tsx','journey/SwarmRunQueue.tsx']:
 def change(s,file=file):
  s=replace(s,'import { WorkflowDialog }','import { WorkflowDialog, type WorkflowDialogReadAccess }') if 'import { WorkflowDialog }' in s else replace(s,'import {WorkflowDialog}','import {WorkflowDialog, type WorkflowDialogReadAccess}')
  s=replace(s,'<WorkflowDialog ','<WorkflowDialog readAccess={readAccess} ')
  if file.endswith('SwarmCheckpointDialog.tsx'):
   s=replace(s,'{run, operation, taskTitle, projectName, canContinue,','{run, operation, taskTitle, projectName, readAccess, canContinue,')
   s=replace(s,'  canContinue: boolean;','  readAccess: WorkflowDialogReadAccess; canContinue: boolean;')
  elif file.endswith('SwarmLaunchRecoveryDialog.tsx'):
   s=replace(s,'{run, operation, taskTitle, projectName, canEdit,','{run, operation, taskTitle, projectName, readAccess, canEdit,')
   s=replace(s,'  canEdit: boolean;','  readAccess: WorkflowDialogReadAccess; canEdit: boolean;')
  elif file.endswith('CheckRecoveryDialog.tsx'):
   s=replace(s,'{run, projectName, canRead,','{run, projectName, readAccess, canRead,')
   s=replace(s,'  run: CheckRun; projectName: string;','  readAccess: WorkflowDialogReadAccess; run: CheckRun; projectName: string;')
  elif file.endswith('AmendmentReview.tsx'):
   s=replace(s,'{ turn, view, busy,','{ turn, view, readAccess, busy,')
   s=replace(s,'  turn: OrchestratorTurn;','  readAccess: WorkflowDialogReadAccess; turn: OrchestratorTurn;')
  else:
   s=replace(s,'  run: ProjectRun; canEdit: boolean;','  readAccess: WorkflowDialogReadAccess; run: ProjectRun; canEdit: boolean;')
   s=replace(s,'  const { run, canEdit, canExecute, busy } = props;','  const { run, readAccess, canEdit, canExecute, busy } = props;')
  return s
 edit(base+file,change)
# Modify files already overlaid while retaining the original bindings.
def more(path,fn):
 p=out/path;s=p.read_text();dst=fn(s);assert s!=dst;p.write_text(dst);changed[path]['afterSHA256']=hashlib.sha256(p.read_bytes()).hexdigest()
more(base+'journey/ProjectSwarm.tsx',lambda s: replace(replace(replace(s,'<SwarmRunQueue key=','<SwarmRunQueue readAccess={projectAccess} key='),'<SwarmLaunchRecoveryDialog\n','<SwarmLaunchRecoveryDialog readAccess={projectAccess}\n'),'<SwarmCheckpointDialog\n','<SwarmCheckpointDialog readAccess={projectAccess}\n'))
more(base+'orchestrator/OrchestratorPanel.tsx',lambda s:replace(s,'<AmendmentReview turn=','<AmendmentReview readAccess={access} turn='))
edit(base+'journey/ProjectChecks.tsx',lambda s:replace(s,'<CheckRecoveryDialog\n','<CheckRecoveryDialog readAccess={{...access, canRead: canRead && !readDenied}}\n'))
# Source project's draft owner, NOT pendingNavigation's target. Keep this isolated for parent policy review.
edit(base+'common/DraftNavigationDialog.tsx',lambda s:replace(replace(replace(s,'import { WorkflowDialog }','import { useProjectAccess } from "../../hooks/useProjectAccess";\nimport { WorkflowDialog }'),'  const pending = useCockpit(state => state.pendingNavigation);','  const pending = useCockpit(state => state.pendingNavigation);\n  const sourceProjectId = useCockpit(state => state.selection.projectId) ?? "";\n  const readAccess = useProjectAccess(sourceProjectId);'),'<WorkflowDialog ','<WorkflowDialog readAccess={{...readAccess, canRead: !!sourceProjectId && readAccess.canRead}} '))
# Optional abort support for bounded exact selected-project display validation only.
edit('desktop/src/api/teams.ts',lambda s:replace(s,'projectAccess: (id: string, projectId: string) => productApi.request<ProjectAccess>(`${teamPath(id)}/projects/${encodeURIComponent(projectId)}/members`),','projectAccess: (id: string, projectId: string, signal?: AbortSignal) => productApi.request<ProjectAccess>(`${teamPath(id)}/projects/${encodeURIComponent(projectId)}/members`, undefined, "GET", 120_000, signal),'))
# Bulk wrapper stays outside WorkflowDialog Activity. No render-time hooks over a varying collection.
def bulk(s):
 s=replace(s,"import { WorkflowDialog } from '../common/WorkflowDialog';","import { WorkflowDialog, type WorkflowDialogReadAccess } from '../common/WorkflowDialog';")
 start=s.index('    {cancelReview && <WorkflowDialog ')
 end=s.index('</WorkflowDialog>}',start)+len('</WorkflowDialog>}')
 s=s[:start]+"    {cancelReview && <SelectedQueueCancelReview selection={selection} pending={pending} onClose={() => setCancelReview(false)} onCancel={() => void apply('cancel')} />}"+s[end:]
 marker='const ProjectCard = memo(function ProjectCard'
 addition='''/** Display admission is for every exact selected project. It never changes the
 * selection or performs queue actions; the action still reauthorizes each row. */
function SelectedQueueCancelReview({selection, pending, onClose, onCancel}: {
  selection: Picked[]; pending: boolean; onClose(): void; onCancel(): void;
}) {
  const workspace = useTeamWorkspace();
  const teamId = workspace?.teamId ?? '';
  const projectIds = JSON.stringify([...new Set(selection.map(row => row.project.id))].sort());
  const key = JSON.stringify([teamScopeGeneration(), teamId, workspace?.revision ?? 0, projectIds]);
  const [observation, setObservation] = useState<{key: string; access: WorkflowDialogReadAccess} | null>(null);
  const blocked = !!workspace?.accessBlocked;
  useEffect(() => {
    if (!teamId || blocked) return;
    const controller = new AbortController();
    const ids = JSON.parse(projectIds) as string[];
    let next = 0, failure = '';
    const read = async () => {
      while (!controller.signal.aborted && next < ids.length) {
        const projectId = ids[next++];
        try {
          const result = await teamsApi.projectAccess(teamId, projectId, controller.signal);
          if (controller.signal.aborted) return;
          if (result.team.id !== teamId || result.projectId !== projectId || !result.permissions.read)
            failure = 'Reading access is unavailable for a selected project.';
        } catch {
          if (!controller.signal.aborted) failure = 'Selected project access could not be confirmed.';
        }
      }
    };
    void Promise.all(Array.from({length: Math.min(4, ids.length)}, read)).then(() => {
      if (!controller.signal.aborted) setObservation({key, access: {canRead: ids.length > 0 && !failure, loading: false, error: failure}});
    });
    return () => controller.abort();
  }, [teamId, blocked, key, projectIds]);
  const readAccess: WorkflowDialogReadAccess = blocked ? {canRead: false, loading: false, error: 'Workspace access must be refreshed before continuing.'}
    : !teamId ? {canRead: selection.length > 0, loading: false, error: ''}
    : observation?.key === key ? observation.access : {canRead: false, loading: true, error: ''};
  return <WorkflowDialog readAccess={readAccess} busy={pending} title="Cancel selected waiting tasks?" description="This removes the selected waiting work from dispatch. Saved context and any existing worker output remain available in each project." onClose={onClose}>
    <ul className="overview-cancel-list">{selection.map(row => <li key={itemKey(row.item)}>{row.project.name} · {row.item.taskTitle}</li>)}</ul>
    <div className="workflow-actions"><Button variant="secondary" disabled={pending} onClick={onClose}>Keep queued</Button><Button disabled={pending || !readAccess.canRead || readAccess.loading || !!readAccess.error} onClick={onCancel}>Cancel {selection.length} waiting {selection.length === 1 ? 'task' : 'tasks'}</Button></div>
  </WorkflowDialog>;
}

'''
 assert marker in s
 return s.replace(marker,addition+marker)
edit(base+'projects/ProjectOverviewBoard.tsx',bulk)
manifest={'baseRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'scope':'External proposed owner-callsite overlays only; uncompiled and untested; no repository edits or runtime launched. Parent owns core WorkflowDialog and permissions suspension.','files':changed}
(root/'owner-call-bindings.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'base':manifest['baseRevision'],'files':len(changed),'root':str(out),'manifestSHA256':hashlib.sha256((root/'owner-call-bindings.json').read_bytes()).hexdigest()}))
