# CLOUD-056 / CLOUD-060 actual source API and browser preparation

**Runtime prepared, unexecuted.** This directory contains source for a proposed acceptance run. Controlled syntax/guard results, when available, are bound separately under `validation/`; they never imply app/browser execution. No build or app/browser launch was performed by the preparation author. The final product SHA is intentionally a required parameter: no previous source or package is silently reused. Root/parent must review and assign quiet build/runtime windows before execution.

## Scope

This runs the actual source-built Go API and web assets, creates a fresh owner/member/team/project through real HTTP APIs, and drives actual Chromium/shadcn UI. It authors a private fixture purpose and unsaved definition draft, opens the real Team access portal at1440px and Team settings portal at390px, revokes/restores membership, observes real typed empty-session403 responses, and checks that inaccessible modal contents and Radix effects disappear. It then verifies retained draft recovery, missing granular project grant handling, and a real definition save after access is restored.

One membership request is explicitly aborted as a transport-failure fixture. Another holds an **actual** missing-membership response for at most8seconds. Privacy/modal/focus assertions complete before releasing that response; screenshots/axe are afterward. A body portal's preserved hidden DOM is not counted as readable if it is absent visually and from the accessibility tree. Definition draft preservation is tested; this scenario does **not** type provider credentials or claim to validate every nested editor. The controlled component tests cover nested modal-owned input preservation separately.

No session is fabricated, imported, or allocated. No worker, model, runtime-install, deployment, queue, check, provider or Docker mutation is allowed. Every service uses the fresh private nonexistent Docker Unix socket. The actual gateway may launch its own team API subprocess; that is an owned source-API process, not an agent worker. No real Docker daemon or unrelated workload is queried, stopped or removed. This is Linux source-app acceptance, not an installed package, native Windows/Tauri, live model, swarm execution or performance pass.

## Prerequisites and review gates

1. Review `launch.mjs`, `scenario.mjs`, `guards.mjs`, `capture.mjs`, `build.py` and `outer-run.py` together. `README-supervisor.md` describes the independent hard-stop contract.
2. Use a clean isolated checkout at the exact final40-character product SHA containing the integrated C056/C060 correction. Preserve all earlier failed/partial receipts. Never change the source beneath a run.
3. Use the supported task-local Node24.19.0, Go1.26.3, npm, Python3, Git and a functioning **non-root** Chromium environment. Browser executable must already exist; there is no browser download in runtime. Do not disable the browser sandbox just to pass this fixture. Build and run as the same non-root fixture account so0700 output/state ownership is valid.
4. Root grants a quiet build window, then separately grants a runtime window. The `--window-granted` flag records that scheduling decision; it is not an automatic capacity/admission determination.
5. Stop if the helper, lockfile, source or matching build receipt changes. Supply exact `--product`; do not substitute a docs-only publication when the build product is a different revision.
6. The fresh-build route does not reuse Go/npm caches. The preferred verified-package reuse route launches no installer/compiler and binds already-installed Playwright/axe files separately. Application state and projects are never reused. Build storage needs room for task caches, locked dependencies and outputs. Runtime parent is an existing non-symlink0700 directory owned by the fixture account. Outer creates a fresh child root. No secrets should be supplied; fixture credentials are generated and never printed.

## Review first, then controlled tests

These commands launch no app/browser/Docker process. Run only after the parent permits a small test window:

```sh
node --check /path/to/preparation/launch.mjs
node --check /path/to/preparation/scenario.mjs
node --check /path/to/preparation/guards.mjs
node --check /path/to/preparation/capture.mjs
node --test --test-concurrency=1 /path/to/preparation/guards.test.mjs
python3 -m py_compile /path/to/preparation/build.py /path/to/preparation/outer-run.py
```

Retain stdout/stderr/exit status and helper hashes. The controlled tests cover exact endpoint scopes, immutable revision, empty-session guard, real typed denial parsing, once-per-episode count assumptions, no fragment/query bypass, PID generation comparison, early response-gate timing, and asynchronous observer failure/drain behavior. They do not establish the real scenario's selectors or native process behavior.

## Build command (not yet run)

Use explicit absolute task-specific paths; `ARTIFACTS` must not exist and must be outside the source checkout. The build wrapper refuses tracked source changes and checks HEAD before/after. It creates private logs and a failure receipt even when a command fails. It does locked npm installation with browser download disabled, a web build, and Go API build; no release is published.

```sh
python3 /path/to/preparation/build.py \
  --repo /isolated/exact-checkout \
  --artifacts /private/build-parent/c060-final-sha-build \
  --product FULL_PRODUCT_SHA \
  --isolated-checkout --window-granted
```

`build-receipt.json` binds the declared tracked desktop/control-plane/sandboxd/module inputs, all transitively imported relative acceptance helper modules, the local preparation files, actual installed Playwright/playwright-core/axe files, API binary and web output files. It records scope; it is not a claim that every external compiler/library byte was independently verified. Build outputs must match the final product before runtime. The build receipt is not a performance or UI pass.

## Preferred reuse of the existing exact package (not yet executed by preparation author)

For product `5f4a966f6d70264c92ee2176dde912e1b43fc3c7`, the root has already built a matching package. Avoid redundant npm/Go/web builds:

```sh
python3 /path/to/preparation/build.py \
  --repo /workspace/luci \
  --artifacts /private/build-parent/c060-5f4a-verified-reuse \
  --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 \
  --reuse-package-provenance /workspace/luci/artifacts/quality-swarm/candidate-5f4a966f/package/package-provenance.json \
  --isolated-checkout --window-granted
```

This route requires exact clean HEAD, verifies the original archive SHA and selected regular binary/web members against extracted package bytes, copies only those matching members into private artifacts, and hashes the copies. It captures installed browser-test dependency files and current source/helper closure. It performs **no npm install, build, browser or app launch**. The publisher's clean-build assertion is retained as provenance, not replaced by a claim to have independently rerun compilation. A different commit/dirty state/hash/file set refuses reuse.

## Runtime command (not yet run)

Use `outer-run.py`, never bare `launch.mjs`, for acceptance. The outer supervisor owns the hard deadline and independent closure observations.

```sh
python3 /path/to/preparation/outer-run.py \
  --repo /isolated/exact-checkout \
  --artifacts /private/build-parent/c060-final-sha-build \
  --chromium /absolute/preinstalled/chromium \
  --parent /private/c060-runs \
  --product FULL_PRODUCT_SHA --window-granted
```

Configured workload deadline is240seconds. Driver cleanup phases are individually bounded within45seconds; the outer envelope is300seconds (240+45+15slack), followed by15seconds of exact-identity TERM grace and bounded final observation. Forced cleanup, timeout, unknown settlement or a missing final receipt is **failure/uncertainty**, never success. No stuck `browser.close()` can prevent the outer receipt. The known process root is checked separately from a marker scan, and PID reuse is not an owned identity. Zombies and unreadable unrelated environments remain literal observations.

## Evidence and closure

The root is private and preserved. Driver writes an immutable exact managed-scope ledger before namespace requests (known owner/member/team only), an atomic known-identity ledger before/after discoveries, `driver-start.json`, compact `driver-result.json`, `evidence/incomplete.json` before cleanup, `evidence/events.jsonl` fsynced per bounded event, compact `evidence/result.json`, and screenshots. Raw event arrays do not compete for the64KiB checkpoint limit. HTTP records exclude credentials and response bodies; selected catalogue body hashes/statuses bind the actual response. Observer failures and premature controller exit poison the workflow. Allowlisted scenario phase codes locate failures. A bounded mode0600 `private-failure.json` preserves original message/cause/stack with generated secret values replaced; it is never automatically published. Public summaries bind its hash only.

The outer supervisor writes its independent before/start/timeout/exit/closure evidence even if driver cleanup blocks. Driver exit or empty Docker inventories are not proof of browser/sidecar closure. Preserve known PID/start identities, late-handle states, zombies, unreadable observations and every forced intervention. The nonexistent socket proves only this fixture's selected Docker transport boundary; no whole-machine Docker/process census is claimed.

If a selector/API/prerequisite fails, retain the original fixture and report that reached stage. Fix the helper in a new immutable preparation revision, rerun only after source/guard review, and never turn a helper fault into a product pass. No latency target is evaluated or adjusted here. C032, Windows, live provider and full swarm/recovery acceptance remain separate.
