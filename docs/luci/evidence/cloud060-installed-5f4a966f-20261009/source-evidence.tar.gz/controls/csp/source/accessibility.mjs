// CLOUD-066 privileged test-tool audit. Standard Playwright evaluation executes
// the pinned axe source for inspection only; no page CSP/header/context changes.
import assert from 'node:assert/strict';
export async function auditBlockedEntry(page,axeSource){
 assert(typeof axeSource==='string'&&axeSource.length>0,'Pinned axe source required');
 await page.evaluate(axeSource);
 return page.evaluate(async()=>window.axe.run('.team-entry',{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}}));
}
