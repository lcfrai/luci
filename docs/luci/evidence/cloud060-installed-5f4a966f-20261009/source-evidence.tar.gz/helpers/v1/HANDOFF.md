# C056/C060 actual-browser preparation ready for parent review

Product pin: `5f4a966f6d70264c92ee2176dde912e1b43fc3c7`.

No app/browser/Docker or Luci build has run from this preparation. This is a controlled-helper checkpoint, not product acceptance.

Controlled evidence:
- `validation/guards-final/summary.json`: six source inputs stable; Node24.19.0, 13/13 guards, five JavaScript syntax checks and Python build-adapter AST check pass. SHA256 `9faa05104e47a7f8f8363deb2fa662a673637974d3c4c0f26d9e8ee4b254ffac`.
- `/workspace/.luci-tools/cloud060-supervisor-validation/followup-result.json`: final unchanged six supervisor controls pass, source stable; SHA256 `5b004ec6a2e86a87acb02c9c5b0f02a4e50b56680cdac537942051c3938381f4`. Actual temporary fsynced preflight/exception/cleanup/final receipts; child spawn and real signal paths forbidden. Exact markerless user/team scope and generation-retention controls use fake /proc observations.
- Preserve original two filename failures, intermediate five passes/one bytearray error, and corrected six controls separately. Do not sum overlapping before/follow-up counts.
- Preserve `validation/guards-attempt1/failure.json`: wrapper referenced a nonexistent task-bin Node path and launched no test. The controlled follow-up used the actual Node24.19.0 executable.

Required parent review before runtime:
1. Inspect final helper bindings and the retained supervisor counterexamples; no original real browser scenario has run yet. Selectors and actual session poll timing remain unverified.
2. Confirm the exact package provenance still points at clean product5f4 and that source is frozen. `build.py` reuse verifies archive SHA, every selected binary/web archive member against extracted package and copied output, full selected file set, original-provenance stability and final source stability. It records the publisher's clean-build claim accurately; no npm install/compiler runs in reuse mode.
3. Review exact runtime scopes: owner/member/team IDs are captured through real HTTP, written once before namespace requests, and map only to their three exact derived managed-runtime state paths. Neither driver nor supervisor uses a broad state-root ownership wildcard. Scope fields include both managed-worker flags and exact execution-authority path, plus actor-or-team identity.
4. The actual no-grant check closes workspace settings before asserting no project content, and also requires the member's exact project specification GET403. A workspace modal cannot mask leaked underlying project content in this oracle.
5. The runtime is intentionally strict: exact owned zombies, unknown observation or forced cleanup fail outer certification. They remain literal observations; no whole-machine zero-process claim.

Commands below are prepared and have NOT been run. Run as the existing non-root `agent` fixture account. Use fresh artifact/root paths; do not clear previous failed fixtures. Root must grant a quiet runtime slot separately from the verified-copy preparation.

```sh
python3 /workspace/.luci-tools/cloud060-real-browser-preparation/build.py \
  --repo /workspace/luci \
  --artifacts /workspace/.luci-tools/cloud060-package-reuse-5f4a966f \
  --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 \
  --reuse-package-provenance /workspace/luci/artifacts/quality-swarm/candidate-5f4a966f/package/package-provenance.json \
  --isolated-checkout --window-granted

mkdir -m 700 /workspace/.luci-tools/cloud060-runs-5f4a966f
python3 /workspace/.luci-tools/cloud060-real-browser-preparation/outer-run.py \
  --repo /workspace/luci \
  --artifacts /workspace/.luci-tools/cloud060-package-reuse-5f4a966f \
  --chromium /usr/lib/chromium/chromium \
  --parent /workspace/.luci-tools/cloud060-runs-5f4a966f \
  --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 --window-granted
```

The executable above is the actual existing Chromium binary, avoiding an unbound shell launcher. Browser sandbox support remains an actual-runtime prerequisite; no `--no-sandbox` fallback is included.

Scope remains actual packaged Go/web application + real isolated source API authority and Chromium UI, with empty sessions and a nonexistent private Docker endpoint. No agent, model, Docker daemon, installed native/Windows application, multi-project workload or C032 performance acceptance is claimed. Private diagnostic receipt retains sanitized original error/cause/stack; public summaries contain only its hash. All event/receipt/cleanup observations are bounded; asynchronous response errors and premature controller exit fail the workflow.
