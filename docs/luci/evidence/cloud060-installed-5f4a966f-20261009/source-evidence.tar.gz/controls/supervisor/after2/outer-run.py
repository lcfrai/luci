#!/usr/bin/env python3
"""PREPARED ONLY: bounded Linux C060 driver supervisor; never a test pass itself.

No group kills, environment dumps, Docker actions, or fixture deletion. A process
exit is not descendant closure. Signalling requires a fresh exact PID/start match
and a pidfd referring to that same identity. See README-supervisor.md.
"""
from __future__ import annotations

import argparse
import errno
import hashlib
import json
import os
import pathlib
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone

WORKFLOW_SECONDS = 240
CLEANUP_SECONDS = 45
SLACK_SECONDS = 15
DRIVER_SECONDS = WORKFLOW_SECONDS + CLEANUP_SECONDS + SLACK_SECONDS
TERM_SECONDS = 15
POST_KILL_SECONDS = 3
MAX_IDENTITIES = 256
MAX_JSON_BYTES = 262144
MAX_SCAN_PIDS = 8192
MAX_ENV_BYTES = 1048576
MAX_SCAN_ISSUES = 64
MAX_EVENTS = 1200
SCAN_SECONDS = 1.0  # Cooperative between /proc reads; not syscall preemption.
NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)


def now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def brief_error(exc):
    # Exception messages can contain credentials or arbitrary child text.
    return {"type": type(exc).__name__, "errno": getattr(exc, "errno", None),
            "messageSHA256": digest(str(exc).encode()),
            "messageBytes": len(str(exc).encode())}


def encode(value):
    data = (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()
    if len(data) > MAX_JSON_BYTES:
        raise ValueError("bounded receipt exceeded")
    return data


def regular_read(path, limit=MAX_JSON_BYTES):
    fd = os.open(path, os.O_RDONLY | NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError("bounded regular file required")
        data = bytearray()
        while len(data) <= limit:
            part = os.read(fd, min(65536, limit + 1 - len(data)))
            if not part:
                break
            data.extend(part)
        after = os.fstat(fd)
        if len(data) > limit or (before.st_dev, before.st_ino, before.st_size,
                               before.st_mtime_ns) != (after.st_dev, after.st_ino,
                                                     after.st_size, after.st_mtime_ns):
            raise ValueError("file changed or exceeds read bound")
        return bytes(data), before
    finally:
        os.close(fd)


def file_binding(path, limit=536870912):
    fd = os.open(path, os.O_RDONLY | NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError("bounded regular input required")
        count, sha = 0, hashlib.sha256()
        while True:
            part = os.read(fd, 65536)
            if not part:
                break
            count += len(part)
            if count > limit:
                raise ValueError("input grew beyond bound")
            sha.update(part)
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise ValueError("input changed while hashing")
        return {"sha256": sha.hexdigest(), "bytes": count}
    finally:
        os.close(fd)


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


class Evidence:
    def __init__(self, root):
        self.root = root
        self.directory = root / "supervisor"
        self.directory.mkdir(mode=0o700)
        self.events = 0
        self.journal = os.open(self.directory / "events.jsonl",
                               os.O_WRONLY | os.O_CREAT | os.O_EXCL | NOFOLLOW, 0o600)
        sync_directory(root)
        sync_directory(self.directory)

    def exclusive(self, name, value):
        if not re.fullmatch(r"[a-z0-9-]+", name):
            raise ValueError("unsafe evidence name")
        name += ".json"
        data = encode(value)
        fd = os.open(self.directory / name,
                     os.O_WRONLY | os.O_CREAT | os.O_EXCL | NOFOLLOW, 0o600)
        try:
            with os.fdopen(fd, "wb", closefd=False) as stream:
                stream.write(data)
                stream.flush()
            os.fsync(fd)
        finally:
            os.close(fd)
        sync_directory(self.directory)
        return {"path": "supervisor/" + name, "sha256": digest(data), "bytes": len(data)}

    def event(self, kind, **values):
        if self.events >= MAX_EVENTS:
            raise ValueError("supervisor event bound exceeded")
        data = encode({"at": now(), "kind": kind, **values})
        if len(data) > 65536:
            raise ValueError("supervisor event too large")
        written = 0
        while written < len(data):
            written += os.write(self.journal, data[written:])
        os.fsync(self.journal)
        self.events += 1

    def close(self):
        os.fsync(self.journal)
        os.close(self.journal)


def canonical_dir(raw, private=False):
    path = pathlib.Path(raw)
    if not path.is_absolute() or str(path.resolve(strict=True)) != str(path):
        raise ValueError("absolute canonical path required")
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode):
        raise ValueError("directory required")
    if private and (info.st_uid != os.getuid() or info.st_mode & 0o077):
        raise ValueError("private current-user directory required")
    return path


def safe_member(root, relative):
    if not isinstance(relative, str) or "\\" in relative:
        raise ValueError("portable relative source path required")
    part = pathlib.PurePosixPath(relative)
    if part.is_absolute() or not part.parts or any(x in (".", "..") for x in part.parts):
        raise ValueError("relative source path escapes root")
    path = root.joinpath(*part.parts)
    if path.resolve(strict=True) != path or not path.is_relative_to(root):
        raise ValueError("linked source path refused")
    return path


def read_identity(pid):
    try:
        raw = pathlib.Path(f"/proc/{pid}/stat").read_bytes()
        if len(raw) > 8192:
            raise ValueError("proc stat bound exceeded")
        end = raw.rfind(b") ")
        fields = raw[end + 2:].split()
        if end < 0 or int(raw[:raw.index(b" ")]) != pid or len(fields) < 20:
            raise ValueError("invalid proc identity")
        return {"status": "present", "pid": pid, "startTicks": int(fields[19]),
                "state": fields[0].decode("ascii"), "parentPid": int(fields[1]),
                "uid": pathlib.Path(f"/proc/{pid}").stat().st_uid}
    except OSError as exc:
        if exc.errno in (errno.ENOENT, errno.ESRCH):
            return {"status": "absent", "pid": pid}
        return {"status": "unknown", "pid": pid, "error": brief_error(exc)}
    except (ValueError, UnicodeError, IndexError) as exc:
        return {"status": "unknown", "pid": pid, "error": brief_error(exc)}


def observation(expected):
    current = read_identity(expected["pid"])
    if current["status"] == "present":
        current["status"] = ("reused" if current["startTicks"] != expected["startTicks"]
                             else "zombie" if current["state"] == "Z" else "same-live")
    return current


class Ownership:
    def __init__(self, root, evidence, product):
        self.root, self.evidence, self.product = root, evidence, product
        self.marker = ("LUCI_C060_RUN_ROOT=" + str(root)).encode()
        self.known = {}
        self.protected = set()
        pid = os.getpid()
        for _ in range(64):
            if pid <= 0 or pid in self.protected:
                break
            self.protected.add(pid)
            item = read_identity(pid)
            if item["status"] != "present":
                break
            pid = item["parentPid"]
        self.ledger_error = None
        self.managed_scope_error = None
        self.managed_scope_digest = None
        self.managed_scopes = {}

    def add(self, row, origin):
        pid, ticks = row.get("pid"), row.get("startTicks")
        if isinstance(pid, bool) or not isinstance(pid, int) or pid <= 1:
            raise ValueError("invalid owned PID")
        if isinstance(ticks, str) and re.fullmatch(r"[0-9]{1,20}", ticks):
            ticks = int(ticks)
        if isinstance(ticks, bool) or not isinstance(ticks, int) or ticks <= 0:
            raise ValueError("invalid owned start ticks")
        if pid in self.protected:
            raise ValueError("supervisor or ancestor cannot be owned child")
        key = (pid, ticks)
        if key not in self.known:
            if len(self.known) >= MAX_IDENTITIES:
                raise ValueError("owned identity bound exceeded")
            role = row.get("role", "scoped-marker")
            if not isinstance(role, str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,47}", role):
                raise ValueError("invalid owned role")
            current = read_identity(pid)
            if current["status"] == "present" and current["uid"] != os.getuid():
                raise ValueError("foreign-UID owned identity refused")
            self.known[key] = {"pid": pid, "startTicks": ticks, "role": role,
                               "origin": origin, "firstObservedAt": now()}
            self.evidence.event("owned-identity", **self.known[key])

    def ledger(self):
        path = self.root / "driver-owned-identities.json"
        try:
            data, info = regular_read(path)
            if info.st_uid != os.getuid() or info.st_mode & 0o077:
                raise ValueError("driver identity ledger must be private")
            value = json.loads(data)
            rows = value.get("identities")
            if value.get("version") != 1 or value.get("runRoot") != str(self.root):
                raise ValueError("identity ledger scope mismatch")
            if not isinstance(rows, list) or len(rows) > MAX_IDENTITIES:
                raise ValueError("identity ledger rows invalid")
            for row in rows:
                if not isinstance(row, dict):
                    raise ValueError("invalid identity ledger row")
                self.add(row, "driver-owned-identities")
            return {"status": "read", "sha256": digest(data), "rows": len(rows)}
        except FileNotFoundError:
            return {"status": "absent"}
        except Exception as exc:
            self.ledger_error = brief_error(exc)
            return {"status": "unknown", "error": self.ledger_error}

    def scope_ledger(self):
        """Accept only once-published, exact driver-known private runtime scopes.

        management.isolatedEnvironment deliberately drops arbitrary fixture
        markers. This exception uses actual fixed worker environment fields;
        it does not authorize a root-descendant path or process wildcard.
        """
        try:
            data, info = regular_read(self.root / "driver-managed-scopes.json", 65536)
            if info.st_uid != os.getuid() or info.st_mode & 0o077:
                raise ValueError("managed scope ledger must be private")
            value = json.loads(data)
            if (value.get("version") != 1 or value.get("runRoot") != str(self.root)
                    or value.get("product") != self.product):
                raise ValueError("managed scope ledger identity mismatch")
            scopes = value.get("scopes")
            if not isinstance(scopes, list) or not 1 <= len(scopes) <= 3:
                raise ValueError("managed scope ledger requires one to three exact scopes")
            accepted = {}
            for row in scopes:
                if not isinstance(row, dict) or row.get("kind") not in ("user", "team"):
                    raise ValueError("invalid managed scope kind")
                ident = row.get("id")
                if not isinstance(ident, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", ident):
                    raise ValueError("unsafe managed scope identity")
                collection = "users" if row["kind"] == "user" else "teams"
                expected = self.root / "state" / "control-plane" / collection / ident / "runtime" / "state"
                if row.get("stateDir") != str(expected) or expected.resolve(strict=False) != expected:
                    raise ValueError("managed scope state directory is not exact private derived path")
                if str(expected) in accepted:
                    raise ValueError("duplicate managed scope")
                accepted[str(expected)] = {"kind": row["kind"], "id": ident, "stateDir": str(expected)}
            current_digest = digest(data)
            if self.managed_scope_digest is not None and current_digest != self.managed_scope_digest:
                raise ValueError("managed scope ledger changed after publication")
            self.managed_scope_digest = current_digest
            self.managed_scopes = accepted
            return {"status": "read", "sha256": current_digest, "rows": len(accepted)}
        except FileNotFoundError:
            if self.managed_scope_digest is not None:
                self.managed_scope_error = {"type": "PreviouslyPublishedScopeLedgerMissing"}
                return {"status": "unknown", "error": self.managed_scope_error}
            return {"status": "absent"}
        except Exception as exc:
            self.managed_scope_error = brief_error(exc)
            return {"status": "unknown", "error": self.managed_scope_error}

    def managed_match(self, entries):
        # Read only these non-secret matching fields. Never retain arbitrary
        # environment entries or LUCI_WORKER_TOKEN in a receipt.
        needed = {b"LUCI_STATE_DIR", b"LUCI_MANAGED_WORKER", b"LUCI_WORKER",
                  b"LUCI_EXECUTION_AUTHORITY_FILE", b"LUCI_ACTOR_ID",
                  b"LUCI_ACTOR_ROLE", b"LUCI_TEAM_ID"}
        fields = {}
        for entry in entries:
            key, separator, value = entry.partition(b"=")
            if separator and key in needed:
                if key in fields:
                    return None  # Duplicate keys make the effective scope ambiguous.
                fields[key] = value
        if (fields.get(b"LUCI_MANAGED_WORKER") != b"1" or fields.get(b"LUCI_WORKER") != b"1"
                or fields.get(b"LUCI_EXECUTION_AUTHORITY_FILE") !=
                os.fsencode(self.root / "state" / "control-plane" / "identity.json")):
            return None
        for scope in self.managed_scopes.values():
            if fields.get(b"LUCI_STATE_DIR") != os.fsencode(scope["stateDir"]):
                continue
            if scope["kind"] == "user":
                if (fields.get(b"LUCI_ACTOR_ID") == scope["id"].encode("ascii")
                        and b"LUCI_TEAM_ID" not in fields):
                    return scope
            elif (fields.get(b"LUCI_TEAM_ID") == scope["id"].encode("ascii")
                  and b"LUCI_ACTOR_ID" not in fields and b"LUCI_ACTOR_ROLE" not in fields):
                return scope
        return None

    def scan(self):
        start = time.monotonic()
        report = {"at": now(), "matched": [], "issues": [], "issueCount": 0,
                  "scanned": 0, "otherUIDSkipped": 0, "complete": True}
        def issue(pid, code):
            report["complete"] = False
            report["issueCount"] += 1
            if len(report["issues"]) < MAX_SCAN_ISSUES:
                report["issues"].append({"pid": pid, "code": code})
        report["managedScopeLedger"] = self.scope_ledger()
        if report["managedScopeLedger"]["status"] == "unknown":
            issue(None, "managed-scope-ledger-unavailable")
        try:
            with os.scandir("/proc") as entries:
                for entry in entries:
                    if not entry.name.isdecimal():
                        continue
                    if report["scanned"] >= MAX_SCAN_PIDS or time.monotonic() - start > SCAN_SECONDS:
                        issue(None, "scan-bound")
                        break
                    pid = int(entry.name)
                    report["scanned"] += 1
                    before = read_identity(pid)
                    if before["status"] == "absent":
                        continue
                    if before["status"] != "present":
                        issue(pid, "identity-unreadable")
                        continue
                    if before["uid"] != os.getuid():
                        report["otherUIDSkipped"] += 1
                        continue
                    try:
                        fd = os.open(f"/proc/{pid}/environ", os.O_RDONLY | os.O_NONBLOCK)
                        try:
                            data = bytearray()
                            while len(data) <= MAX_ENV_BYTES:
                                part = os.read(fd, min(65536, MAX_ENV_BYTES + 1 - len(data)))
                                if not part:
                                    break
                                data.extend(part)
                        finally:
                            os.close(fd)
                        if len(data) > MAX_ENV_BYTES:
                            issue(pid, "environment-bound")
                            continue
                        entries = bytes(data).split(b"\0")
                        marker_match = self.marker in entries
                        managed_scope = self.managed_match(entries)
                        matched = marker_match or managed_scope is not None
                        del entries
                        del data  # Never record environment or secret values.
                        after = read_identity(pid)
                        if after["status"] == "absent":
                            continue
                        if after["status"] != "present":
                            issue(pid, "identity-unreadable-after-environment")
                            continue
                        if after["startTicks"] != before["startTicks"]:
                            issue(pid, "identity-changed-during-environment")
                            continue
                        if matched:
                            try:
                                origin = "exact-run-marker" if marker_match else "exact-managed-scope"
                                if managed_scope is not None:
                                    after["role"] = "managed-" + managed_scope["kind"] + "-runtime"
                                self.add(after, origin)
                                report["matched"].append({"pid": pid, "startTicks": after["startTicks"],
                                    "state": after["state"], "origin": origin,
                                    "managedScope": managed_scope})
                            except (ValueError, OSError):
                                issue(pid, "owned-identity-record-refused")
                    except OSError as exc:
                        if exc.errno not in (errno.ENOENT, errno.ESRCH):
                            issue(pid, "environment-unreadable-" + str(exc.errno))
        except OSError as exc:
            issue(None, "proc-enumeration-" + str(exc.errno))
        report["elapsedSeconds"] = time.monotonic() - start
        return report

    def observations(self):
        return [{"expected": row, "observed": observation(row)} for row in self.known.values()]

    def exact_signal(self, expected, sig):
        row = {"expected": expected, "signal": sig.name}
        if expected["pid"] in self.protected:
            row["status"] = "protected-refused"
        else:
            first = observation(expected)
            row["before"] = first
            if first["status"] != "same-live" or first.get("uid") != os.getuid():
                row["status"] = "not-proven-live-refused"
            else:
                fd = None
                try:
                    fd = os.pidfd_open(expected["pid"], 0)
                    second = observation(expected)
                    row["afterPidfdOpen"] = second
                    if second["status"] != "same-live" or second.get("uid") != os.getuid():
                        row["status"] = "changed-or-unknown-refused"
                    else:
                        signal.pidfd_send_signal(fd, sig)
                        row["status"] = "sent-to-pidfd"
                except OSError as exc:
                    row["status"] = "signal-error"
                    row["error"] = brief_error(exc)
                finally:
                    if fd is not None:
                        os.close(fd)
        self.evidence.event("exact-signal", **row)
        return row


def build_bindings(repo, artifacts, helper_dir, product, node, chromium):
    raw, _ = regular_read(artifacts / "build-receipt.json", 16777216)
    build = json.loads(raw)
    if build.get("product") != product or build.get("passed") is not True or build.get("sourceStable") is not True:
        raise ValueError("exact successful stable build receipt required")
    selected = {}
    for name, base in (("sourceInputs", repo), ("outputs", artifacts)):
        rows = build.get(name)
        if not isinstance(rows, list) or not rows or len(rows) > 8192:
            raise ValueError("build input/output binding list required")
        for row in rows:
            path = safe_member(base, row["path"])
            actual = file_binding(path)
            if not re.fullmatch(r"[a-f0-9]{64}", row["sha256"]) or actual["sha256"] != row["sha256"]:
                raise ValueError("build member mismatch")
            key = name + ":" + row["path"]
            if key in selected:
                raise ValueError("duplicate build member")
            selected[key] = actual
    for path in ("control-plane/internal/management/management.go",
                 "control-plane/internal/management/runtime.go",
                 "control-plane/internal/management/team_runtime.go"):
        if "sourceInputs:" + path not in selected:
            raise ValueError("managed runtime scope production contract is not source-bound")
    helpers = {}
    for path in sorted(helper_dir.iterdir()):
        if path.suffix in (".mjs", ".py", ".md"):
            if len(helpers) >= 64:
                raise ValueError("helper inventory bound exceeded")
            helpers[path.name] = file_binding(path, 2097152)
    if "launch.mjs" not in helpers or "outer-run.py" not in helpers:
        raise ValueError("driver and supervisor source required")
    return {"buildReceipt": {"sha256": digest(raw), "bytes": len(raw)},
            "selected": selected, "helpers": helpers,
            "executables": {"node": file_binding(node), "chromium": file_binding(chromium)}}


def git_head(repo):
    git = shutil.which("git")
    if not git:
        raise ValueError("git unavailable")
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LANG": "C",
           "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null",
           "GIT_OPTIONAL_LOCKS": "0"}
    result = subprocess.run([git, "-C", str(repo), "rev-parse", "--verify", "HEAD"],
                            env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, timeout=10, check=True)
    if not re.fullmatch(rb"[a-f0-9]{40}\n", result.stdout):
        raise ValueError("invalid repository HEAD")
    return result.stdout.decode().strip()


def final_driver_result(root, product):
    try:
        data, info = regular_read(root / "driver-result.json")
        if info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ValueError("driver result must be private")
        value = json.loads(data)
        if (value.get("version") != 1 or value.get("runRoot") != str(root)
                or value.get("product") != product or not isinstance(value.get("passed"), bool)
                or not isinstance(value.get("cleanup"), dict)):
            raise ValueError("driver result identity/schema mismatch")
        return {"status": "read", "sha256": digest(data), "bytes": len(data),
                "passed": value["passed"], "cleanupClaimOnly": True}
    except Exception as exc:
        return {"status": "unknown", "error": brief_error(exc)}


def run(args):
    if sys.platform != "linux" or os.getuid() == 0:
        raise ValueError("Linux nonroot execution required")
    if not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        raise ValueError("Python Linux pidfd support required; unsafe PID-only fallback refused")
    if not args.window_granted or not re.fullmatch(r"[a-f0-9]{40}", args.product):
        raise ValueError("explicit runtime window and exact lowercase product revision required")
    os.umask(0o077)
    repo = canonical_dir(args.repo)
    artifacts = canonical_dir(args.artifacts)
    parent = canonical_dir(args.parent, private=True)
    helper_dir = pathlib.Path(__file__).resolve().parent
    chromium = pathlib.Path(args.chromium)
    node_string = shutil.which("node")
    if not node_string:
        raise ValueError("Node unavailable")
    node = pathlib.Path(node_string).resolve(strict=True)
    if not chromium.is_absolute() or chromium.resolve(strict=True) != chromium or not os.access(chromium, os.X_OK):
        raise ValueError("canonical executable Chromium path required")
    root = pathlib.Path(tempfile.mkdtemp(prefix="c060-run-", dir=parent))
    root.chmod(0o700)
    private_driver_paths = {name: root / suffix for name, suffix in (
        ("HOME", "driver-home"), ("TMPDIR", "driver-tmp"),
        ("XDG_CONFIG_HOME", "driver-config"), ("XDG_CACHE_HOME", "driver-cache"),
        ("XDG_DATA_HOME", "driver-data"), ("XDG_RUNTIME_DIR", "driver-runtime"))}
    for path in private_driver_paths.values():
        path.mkdir(mode=0o700)
    sync_directory(root)
    sync_directory(parent)
    evidence = Evidence(root)
    own = Ownership(root, evidence, args.product)
    child = None
    reasons, interrupted = [], []
    before = None
    exit_code = None
    forced = False
    cleanup_attempted = False
    started = time.monotonic()
    old_handlers = {}
    for sig in (signal.SIGTERM, signal.SIGINT):
        old_handlers[sig] = signal.getsignal(sig)
        signal.signal(sig, lambda received, _frame: interrupted.append(received) if len(interrupted) < 4 else None)
    command = [str(node), str(helper_dir / "launch.mjs"), "--repo", str(repo),
               "--artifacts", str(artifacts), "--chromium", str(chromium),
               "--parent", str(parent), "--product", args.product, "--window-granted",
               "--run-root", str(root)]
    try:
        evidence.exclusive("preflight", {"version": 1, "at": now(), "product": args.product,
            "runRoot": str(root), "executed": False, "command": command,
            "privateDriverPaths": {name: str(path) for name, path in private_driver_paths.items()},
            "budgetsSeconds": {"workflow": WORKFLOW_SECONDS, "cleanup": CLEANUP_SECONDS,
                "driverSlack": SLACK_SECONDS, "driverEnvelope": DRIVER_SECONDS,
                "termGrace": TERM_SECONDS, "postKillObservation": POST_KILL_SECONDS},
            "supervisorIdentity": read_identity(os.getpid()), "protectedPIDs": sorted(own.protected)})
        if git_head(repo) != args.product:
            raise ValueError("repository revision differs from requested product")
        before = build_bindings(repo, artifacts, helper_dir, args.product, node, chromium)
        # Source manifests can exceed the per-receipt cap; bind an exclusive
        # per-member JSONL without exposing arbitrary build receipt contents.
        binding_fd = os.open(evidence.directory / "input-bindings.jsonl",
                             os.O_WRONLY | os.O_CREAT | os.O_EXCL | NOFOLLOW, 0o600)
        try:
            with os.fdopen(binding_fd, "wb", closefd=False) as stream:
                for category, members in before.items():
                    if category == "buildReceipt":
                        stream.write(encode({"category": category, **members}))
                    else:
                        for name, binding in members.items():
                            stream.write(encode({"category": category, "path": name, **binding}))
                stream.flush()
            os.fsync(binding_fd)
        finally:
            os.close(binding_fd)
        sync_directory(evidence.directory)
        initial_scan = own.scan()
        evidence.exclusive("before-launch", {"version": 1, "at": now(), "product": args.product,
            "runRoot": str(root), "command": command, "markerScan": initial_scan,
            "inputBindings": file_binding(evidence.directory / "input-bindings.jsonl")})
        if initial_scan["matched"]:
            raise ValueError("fresh run marker unexpectedly already present")
        if interrupted:
            raise InterruptedError("interrupted before child launch")
        env = {key: os.environ[key] for key in ("PATH", "LANG", "LC_ALL", "TZ") if key in os.environ}
        env.update({name: str(path) for name, path in private_driver_paths.items()})
        env["TMP"] = env["TEMP"] = env["TMPDIR"]
        env["LUCI_C060_RUN_ROOT"] = str(root)
        launch_time = time.monotonic()
        child = subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 close_fds=True, start_new_session=True)
        identity = read_identity(child.pid)
        if identity["status"] != "present":
            raise ValueError("driver exact identity unavailable immediately after launch")
        own.add({**identity, "role": "driver"}, "direct-child")
        evidence.exclusive("launched", {"version": 1, "at": now(), "identity": identity,
                                      "deadlineMonotonic": launch_time + DRIVER_SECONDS})
        next_scan = 0.0
        while child.poll() is None:
            if interrupted:
                reasons.append("supervisor-interrupted")
                evidence.exclusive("interrupted", {"at": now(), "signals": interrupted,
                    "owned": own.observations(), "driverExit": child.poll()})
                break
            if time.monotonic() >= launch_time + DRIVER_SECONDS:
                reasons.append("driver-envelope-exceeded")
                evidence.exclusive("timeout", {"at": now(), "allowedSeconds": DRIVER_SECONDS,
                    "elapsedSeconds": time.monotonic() - launch_time, "owned": own.observations(),
                    "driverExit": child.poll(), "cleanupStatus": "not-yet-proven"})
                break
            if time.monotonic() >= next_scan:
                ledger, scan = own.ledger(), own.scan()
                evidence.event("ownership-observation", ledger=ledger, scan=scan)
                next_scan = time.monotonic() + 2
            time.sleep(0.2)
        exit_code = child.poll()
        evidence.exclusive("driver-exit-observation", {"at": now(), "returnCode": exit_code,
            "reason": reasons, "owned": own.observations(),
            "note": "Driver exit alone is not descendant cleanup proof"})
    except Exception as exc:
        reasons.append("supervisor-exception")
        evidence.exclusive("exception", {"at": now(), "error": brief_error(exc),
                                         "owned": own.observations()})
    finally:
        # Durable incomplete checkpoint precedes every possibly slow cleanup
        # operation, including /proc scans. Original receipts are never replaced.
        evidence.exclusive("cleanup-entered", {"at": now(), "passed": False,
            "known": list(own.known.values()), "reasons": reasons,
            "driverReturnCode": child.poll() if child else None})
        ledger = own.ledger()
        scan = own.scan()
        rows = own.observations()
        need_cleanup = any(row["observed"]["status"] == "same-live" for row in rows)
        if need_cleanup:
            cleanup_attempted = True
            reasons.append("last-resort-cleanup-needed")
            evidence.exclusive("last-resort-start", {"at": now(), "owned": rows,
                                                     "ledger": ledger, "scan": scan})
            term_end = time.monotonic() + TERM_SECONDS
            signalled = set()
            while True:
                for item in own.known.values():
                    key = (item["pid"], item["startTicks"])
                    if key not in signalled:
                        own.exact_signal(item, signal.SIGTERM)
                        signalled.add(key)
                if child:
                    child.poll()  # Reap our direct child without blocking.
                if not any(row["observed"]["status"] == "same-live" for row in own.observations()):
                    break
                if time.monotonic() >= term_end:
                    break
                time.sleep(0.2)
                own.ledger()
                own.scan()  # Adopt late detached children by exact marker.
            live = [row["expected"] for row in own.observations()
                    if row["observed"]["status"] == "same-live"]
            if live:
                forced = True
                reasons.append("forced-cleanup")
                evidence.exclusive("before-force", {"at": now(), "identities": live,
                    "uncertain": [x for x in own.observations() if x["observed"]["status"] == "unknown"]})
                for item in live:
                    own.exact_signal(item, signal.SIGKILL)
                stop = time.monotonic() + POST_KILL_SECONDS
                while time.monotonic() < stop:
                    if child:
                        child.poll()
                    if not any(row["observed"]["status"] == "same-live" for row in own.observations()):
                        break
                    time.sleep(0.1)
        final_ledger = own.ledger()
        final_scan = own.scan()
        if child:
            exit_code = child.poll()
        observations = own.observations()
        live = [x for x in observations if x["observed"]["status"] == "same-live"]
        unknown = [x for x in observations if x["observed"]["status"] == "unknown"]
        zombies = [x for x in observations if x["observed"]["status"] == "zombie"]
        driver_result = final_driver_result(root, args.product)
        inputs_stable, input_error = False, None
        if before is not None:
            try:
                inputs_stable = (before == build_bindings(repo, artifacts, helper_dir,
                                                        args.product, node, chromium)
                                 and git_head(repo) == args.product)
            except Exception as exc:
                input_error = brief_error(exc)
        scoped_closure = not live and not unknown and final_scan["complete"] and not final_scan["matched"]
        # Zombies are explicitly not zero-PID closure. They fail this fresh run's
        # strict complete-process closure gate; they are never signalled as live.
        passed = (child is not None and exit_code == 0 and not reasons and not interrupted
                  and not cleanup_attempted and not forced and scoped_closure and not zombies
                  and own.ledger_error is None and final_ledger["status"] == "read"
                  and own.managed_scope_error is None and final_scan["managedScopeLedger"]["status"] == "read"
                  and inputs_stable and driver_result.get("passed") is True)
        result = {"version": 1, "at": now(), "product": args.product, "runRoot": str(root),
            "passed": passed, "runtimeExecuted": child is not None, "returnCode": exit_code,
            "elapsedSeconds": time.monotonic() - started, "reasons": reasons,
            "interruptedSignals": interrupted, "lastResortCleanupAttempted": cleanup_attempted,
            "forcedCleanup": forced, "inputsStable": inputs_stable, "inputError": input_error,
            "driverResult": driver_result, "identityLedger": final_ledger,
            "priorLedgerObservationError": own.ledger_error, "finalMarkerScan": final_scan,
            "managedScopeObservationError": own.managed_scope_error,
            "managedScopeLedgerSHA256": own.managed_scope_digest,
            "managedScopes": list(own.managed_scopes.values()),
            "ownedObservations": observations, "zombies": zombies,
            "knownLiveCount": len(live), "knownUnknownCount": len(unknown),
            "scopedProcessClosureProven": scoped_closure and not zombies,
            "wholeMachineClosureClaim": False,
            "limitations": ["Same-UID unreadable process environments remain observation uncertainty",
                "Marker scans can miss short-lived processes between samples",
                "Synchronous filesystem/proc reads and fsync have cooperative bounds, not kernel preemption",
                "No Docker, provider, worker, Windows or performance acceptance is inferred"]}
        reference = evidence.exclusive("final", result)
        evidence.event("supervisor-finished", passed=passed, final=reference)
        evidence.close()
        for sig, previous in old_handlers.items():
            signal.signal(sig, previous)
        print(json.dumps({"passed": passed, "runRoot": str(root), "receipt": reference}, sort_keys=True))
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--repo", required=True)
    parser.add_argument("--artifacts", required=True)
    parser.add_argument("--chromium", required=True)
    parser.add_argument("--parent", required=True)
    parser.add_argument("--product", required=True)
    parser.add_argument("--window-granted", action="store_true")
    args = parser.parse_args()
    try:
        return run(args)
    except Exception as exc:
        # Failures before a fresh evidence directory exists cannot leave a
        # scoped on-disk receipt; never print uncontrolled exception contents.
        print(json.dumps({"passed": False, "supervisorIncomplete": True,
                          "error": brief_error(exc)}, sort_keys=True), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
