import { Activity, useRef, useState, type ReactNode } from "react";
import { useDismissable } from "../../hooks/useDismissable";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../fluid/components/dialog";
import { useWorkspaceOverlayAvailable } from "./WorkspaceOverlayScope";
import "./workflow-dialog.css";

type WorkflowDialogProps = {
  title: string; description: string; busy?: boolean; onClose(): void; children: ReactNode;
  getCloseFocusTarget?(openingControl: HTMLElement | null): HTMLElement | null;
};

/** Retain modal-owned drafts while disconnected workspace access suspends presentation. */
export function WorkflowDialog(props: WorkflowDialogProps) {
  const available = useWorkspaceOverlayAvailable();
  const latestAvailable = useRef(available); latestAvailable.current = available;
  const [returnFocusTo] = useState<HTMLElement | null>(() =>
    typeof document !== "undefined" && document.activeElement instanceof HTMLElement ? document.activeElement : null,
  );
  // Activity also hides React portals and disconnects modal effects, while
  // retaining nested form state. CSS on the host alone cannot do either.
  // C056 reopens this scope only after current membership and fresh project /
  // session catalogues have been applied; their owners still control mounting.
  return <Activity mode={available ? "visible" : "hidden"}>
    <WorkflowDialogModal {...props} returnFocusTo={returnFocusTo} mayRestoreFocus={() => latestAvailable.current} />
  </Activity>;
}

function WorkflowDialogModal({ title, description, busy = false, onClose, getCloseFocusTarget, children, returnFocusTo, mayRestoreFocus }: WorkflowDialogProps & {
  returnFocusTo: HTMLElement | null; mayRestoreFocus(): boolean;
}) {
  const panel = useDismissable<HTMLDivElement>(true, () => { if (!busy) onClose(); }, false);
  const restore = useRef(mayRestoreFocus); restore.current = mayRestoreFocus;
  return <Dialog open onOpenChange={open => { if (!open && !busy) onClose(); }}>
    <DialogContent ref={panel} size="lg" showCloseButton={false} aria-modal="true"
      onCloseAutoFocus={event => {
        event.preventDefault();
        if (!restore.current()) return;
        const target = getCloseFocusTarget ? getCloseFocusTarget(returnFocusTo) : returnFocusTo;
        if (target?.isConnected && !target.closest("[hidden], [inert]")) target.focus();
      }}
      onEscapeKeyDown={event => { if (busy) event.preventDefault(); }}
      onPointerDownOutside={event => { if (busy) event.preventDefault(); }}>
      <DialogHeader><DialogTitle>{title}</DialogTitle><DialogDescription>{description}</DialogDescription></DialogHeader>
      {children}
    </DialogContent>
  </Dialog>;
}
