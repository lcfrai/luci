# CLOUD-062: separate corrected rail-navigation helper

Product stays `5f4a966f6d70264c92ee2176dde912e1b43fc3c7`; no product or repository changes. V2 runtime has not run. V1 exact helpers and both original failed fixtures remain unchanged; see `evidence/original-failure-projection.json` for immutable original result bindings.

CLOUD-061 is the Unix-socket fixture path limit: the first browser factory aborted on its long temporary socket path. The second invocation shortened only `--parent` and reached Chromium plus the authorized project overview. It then exposed CLOUD-062: `isVisible()` does not establish an offscreen/inert rail control is actionable. The helper could also blindly toggle an already-expanded rail during transient workspace hiding. The exact origin of that run’s collapsed state was not captured; the correction must not invent it.

V2 uses Projects `aria-expanded`, current visible workspace-host admission and selected workspace identity; no forced clicks or direct application-state mutation. Readiness waits do not require a closed compact rail’s select to be interactable. Navigation assertions and exact owner scope remain; portal privacy, consent, focus, ARIA, pointer, scroll, draft and 403 checks are unchanged. Final controlled evidence is `validation/navigation/final/summary.json`: 19 cases pass (two expected exact-original counterexamples and 17 corrected cases), plus three syntax checks. The matrix covers desktop/compact collapsed and expanded rails, delayed display-contents host readiness, wrong and changing workspace, cancellation, bounded reads and ambiguous hosts. `validation/navigation/handoff.json` binds the unchanged 8,004-byte privacy/focus suffix. The initial syntax-only fixture error and later incomplete display-contents fixture are retained; the added exact layout regression fails against that intermediate helper and passes after correction. These are inert helper controls, not a browser or product pass.

Package preparation launches no compiler/npm/app/browser/Docker. Root’s package archive, extracted selected binary/web members and copied bytes must all match, with exact clean source and helper bindings:

```sh
python3 /workspace/.luci-tools/cloud060-real-browser-v2/build.py \
  --repo /workspace/luci \
  --artifacts /workspace/.luci-tools/cloud060-package-reuse-v2-5f4a966f \
  --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 \
  --reuse-package-provenance /workspace/luci/artifacts/quality-swarm/candidate-5f4a966f/package/package-provenance.json \
  --isolated-checkout --window-granted
```

Root schedules and launches the actual runtime; use the existing short private 0700 parent (outer creates a fresh unique child). Do not clear/reuse prior run state:

```sh
python3 /workspace/.luci-tools/cloud060-real-browser-v2/outer-run.py \
  --repo /workspace/luci \
  --artifacts /workspace/.luci-tools/cloud060-package-reuse-v2-5f4a966f \
  --chromium /usr/lib/chromium/chromium \
  --parent /workspace/.t/c60 \
  --product 5f4a966f6d70264c92ee2176dde912e1b43fc3c7 --window-granted
```

The first observed actual Chromium argument list included Playwright-added `--no-sandbox`; code omitting that explicit argument is not proof a sandbox was enabled. This acceptance fixture makes no Chromium sandbox, native Windows, agent/provider, Docker daemon or performance claim.

Keep cleanup scopes separate. Known exact PID/start absence does not imply wholehost scan completeness. Original attempt1 observed four known identities absent; final scan retained 6256 uncertain environment reads. Current stat-only inspection of the 64 retained issue samples finds preexisting same-UID zombies, not proof about all 6256 historical observations. Original attempt2 retains two exact owned Chromium PID1 zombies. Neither original uncertainty nor zombie result is waived by v2; supervisor cleanup semantics are unchanged.
