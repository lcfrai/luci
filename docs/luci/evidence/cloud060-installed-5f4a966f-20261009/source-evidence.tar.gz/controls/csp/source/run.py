from pathlib import Path
import os,sys,json,time,hashlib,subprocess,tempfile,signal,shutil
p=Path(__file__).resolve().parent;root=Path(tempfile.mkdtemp(prefix='c66-',dir='/workspace/.t'));root.chmod(0o700);os.umask(0o077)
def save(name,value):
 data=(json.dumps(value,indent=2)+'\n').encode();tmp=root/(name+'.tmp')
 with tmp.open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 tmp.replace(root/name)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
paths=[p/'fixture.mjs',p/'run.py',Path('/workspace/.luci-tools/cloud060-real-browser-v4/accessibility.mjs'),Path('/workspace/luci/control-plane/cmd/api/web.go'),Path('/workspace/luci/desktop/node_modules/axe-core/axe.min.js'),Path('/workspace/luci/desktop/node_modules/axe-core/package.json'),Path('/workspace/luci/desktop/node_modules/playwright-core/lib/coreBundle.js'),Path('/workspace/luci/desktop/node_modules/playwright-core/package.json')]
def bindings():return [{'path':str(x),'sha256':digest(x),'bytes':x.stat().st_size}for x in paths]
def identity(pid):
 try:
  raw=Path('/proc',str(pid),'stat').read_text();parts=raw[raw.rfind(')')+2:].split();return {'pid':pid,'startTicks':parts[19],'state':parts[0]}
 except (FileNotFoundError,ProcessLookupError):return None
known={};unknown=set();marker=('LUCI_C066_ROOT='+str(root)).encode();events=[]
def scan():
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  pid=int(proc.name)
  try:
   if marker not in (proc/'environ').read_bytes().split(b'\0'):continue
   current=identity(pid)
   if current:
    key=(pid,current['startTicks'])
    if key not in known:
     current['argv']=[x.decode(errors='replace')for x in (proc/'cmdline').read_bytes().split(b'\0') if x];known[key]=current
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:unknown.add(pid)
 save('owned-observations.json',{'known':list(known.values()),'unreadableEnvironments':sorted(unknown)})
def send_exact(old,sig):
 now=identity(old['pid'])
 if not now or now['startTicks']!=old['startTicks'] or now['state']=='Z':return
 fd=os.pidfd_open(old['pid']);again=identity(old['pid'])
 try:
  if again and again['startTicks']==old['startTicks']:signal.pidfd_send_signal(fd,sig);events.append({'pid':old['pid'],'startTicks':old['startTicks'],'signal':sig.name})
 finally:os.close(fd)
before=bindings();argv=[shutil.which('node'),'--max-old-space-size=192',str(p/'fixture.mjs')];env={key:os.environ[key] for key in ['PATH','LANG','LC_ALL','TZ'] if key in os.environ};env.update(LUCI_C066_ROOT=str(root),HOME=str(root),TMPDIR=str(root),XDG_CONFIG_HOME=str(root/'config'),XDG_CACHE_HOME=str(root/'cache'))
save('preflight.json',{'argv':argv,'cwd':str(p),'root':str(root),'inputs':before,'deadlineSeconds':80,'cleanupGraceSeconds':8});start=time.monotonic();forced=False
with (root/'stdout.log').open('wb') as stdout,(root/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(argv,cwd=p,env=env,stdout=stdout,stderr=stderr,start_new_session=True);first=identity(child.pid);assert first;known[(first['pid'],first['startTicks'])]=dict(first,argv=argv)
 while child.poll() is None and time.monotonic()-start<80:scan();time.sleep(.1)
 scan()
 if child.poll() is None:
  forced=True;save('deadline.json',{'failure':'outer driver deadline','known':list(known.values())})
  for row in list(known.values()):send_exact(row,signal.SIGTERM)
  try:child.wait(timeout=3)
  except subprocess.TimeoutExpired:
   for row in list(known.values()):send_exact(row,signal.SIGKILL)
   child.wait(timeout=2)
 for _ in range(10):scan();time.sleep(.1)
 observations=[{'initial':row,'final':identity(row['pid'])}for row in known.values()]
 live=[x for x in observations if x['final'] and x['final']['startTicks']==x['initial']['startTicks'] and x['final']['state']!='Z']
 if live:
  forced=True
  for x in live:send_exact(x['initial'],signal.SIGTERM)
  time.sleep(1)
  for x in live:send_exact(x['initial'],signal.SIGKILL)
  time.sleep(.2)
 observations=[{'initial':row,'final':identity(row['pid'])}for row in known.values()];after=bindings();report=json.loads((root/'report.json').read_text())if(root/'report.json').exists()else None
 result={'scope':'One lightweight actual HTTP+CSP Chromium control; privileged audit-tool evaluation only','root':str(root),'argv':argv,'cwd':str(p),'exitCode':child.returncode,'seconds':time.monotonic()-start,'forced':forced,'signals':events,'before':before,'after':after,'sourceStable':before==after,'workflowPassed':bool(report and report['passed']),'owned':observations,'unreadableEnvironmentPIDs':sorted(unknown),'fullyAbsentKnown':all(x['final'] is None or x['final']['startTicks']!=x['initial']['startTicks'] for x in observations),'noKnownOwnedLive':not any(x['final'] and x['final']['startTicks']==x['initial']['startTicks'] and x['final']['state']!='Z' for x in observations),'noSandboxObserved':any('--no-sandbox' in x['initial'].get('argv',[])for x in observations),'reportSHA256':digest(root/'report.json')if report else None,'notWholeMachineClosure':True};save('result.json',result);print(json.dumps({'root':str(root),'exitCode':child.returncode,'seconds':result['seconds'],'workflowPassed':result['workflowPassed'],'forced':forced,'noKnownOwnedLive':result['noKnownOwnedLive'],'fullyAbsentKnown':result['fullyAbsentKnown'],'resultSHA256':digest(root/'result.json')}))
