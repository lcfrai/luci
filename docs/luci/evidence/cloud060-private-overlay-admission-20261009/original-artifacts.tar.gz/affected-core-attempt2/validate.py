import hashlib,json,os,pathlib,signal,subprocess,sys,time,shutil
stage=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/workspace/luci');out=stage/sys.argv[1];out.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
def write(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
def capture():
 paths=sorted(p for p in (repo/'desktop/src').rglob('*') if p.is_file() and p.suffix in ['.ts','.tsx','.css','.json','.svg'])+[repo/'desktop/package.json',repo/'desktop/package-lock.json',repo/'desktop/vitest.config.ts',repo/'desktop/tsconfig.json']
 return [{'path':str(p.relative_to(repo)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths]
for name in ['authority-portals.test.tsx','bulk-portals.test.tsx','typecheck.cjs','validate.py']:
 shutil.copyfile(stage/name,out/name)
shutil.copytree(stage/'after',out/'after');(out/'node_modules').symlink_to(repo/'desktop/node_modules',target_is_directory=True)
original=(stage/'config.mts').read_text().replace("stage='/workspace/.luci-tools/cloud060-workspace-portals'",'stage='+json.dumps(str(out)))
files=[line.strip() for line in (stage/'affected-files.txt').read_text().splitlines() if line.strip()]
original=original.replace("include:[stage+'/authority-portals.test.tsx']","include:[stage+'/authority-portals.test.tsx',stage+'/bulk-portals.test.tsx',"+','.join('root+'+json.dumps('/'+p) for p in files)+']')
(out/'config.mts').write_text(original);shutil.copyfile(stage/'affected-files.txt',out/'affected-files.txt')
inputs=[]
for p in sorted(out.rglob('*')):
 if p.is_file():inputs.append({'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
write('frozen-inputs.json',inputs);before=capture();write('source-before.json',before)
write('versions.json',{k:subprocess.check_output(v,text=True).strip() for k,v in {'node':['node','--version'],'npm':['npm','--version'],'head':['git','-C',str(repo),'rev-parse','HEAD']}.items()})
results=[]
commands=[('affected',['node','node_modules/vitest/vitest.mjs','run','--config',str(out/'config.mts'),'--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'report.json')]),('typecheck',['node',str(out/'typecheck.cjs')])]
if len(sys.argv)>2 and sys.argv[2]=='tests-only':commands=commands[:1]
for name,cmd in commands:
 start=time.time();timeout=False;env=os.environ.copy();env['CLOUD060_FIXED']='1';env.pop('CLOUD060_CORE_ONLY',None);env.pop('CLOUD060_NESTED_ORIGINAL',None);env['CLOUD060_TS_BINDINGS']=str(out/'typecheck-inputs.json')
 with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
  proc=subprocess.Popen(cmd,cwd=repo/'desktop',stdout=stdout,stderr=stderr,env=env,start_new_session=True)
  try:code=proc.wait(timeout=120)
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(proc.pid,signal.SIGTERM)
   try:code=proc.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=5)
 row={'kind':name,'command':cmd,'environment':{'CLOUD060_FIXED':'1','CLOUD060_CORE_ONLY':None},'exitCode':code,'timedOut':timeout,'seconds':time.time()-start,'ownedRootPID':proc.pid,'rootWaited':True};results.append(row);write('commands.json',results);print(json.dumps(row),flush=True)
after=capture();write('source-after.json',after);write('result.json',{'commands':results,'sourceStable':before==after,'sourceInputs':len(before),'scope':'Controlled actual components/Radix plus external TypeScript compiler host overlays; no real app/browser/provider/Docker; no whole-machine census'})
sys.exit(0 if before==after and all(r['exitCode']==0 for r in results) else 1)
