#!/usr/bin/env python3
"""Run only inert supervisor controls with retained original/fixed evidence."""
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = ROOT.parent / "cloud060-real-browser-preparation/outer-run.py"
FILES = [SOURCE, ROOT / "before/outer-run.py", ROOT / "after/outer-run.py",
         ROOT / "controlled.py", pathlib.Path(__file__).resolve()]

def bindings():
    return [{"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
             "bytes": p.stat().st_size} for p in FILES]

def exclusive(path, data):
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())

def main():
    before = bindings()
    if SOURCE.read_bytes() != (ROOT / "after/outer-run.py").read_bytes():
        raise RuntimeError("frozen final source mismatch")
    runs = []
    for label, names in (("before", [
            "SupervisorControls.test_bare_receipt_names_write_fsynced_exclusive_json",
            "SupervisorControls.test_no_launch_preflight_failure_persists_exception_cleanup_and_final"]),
            ("after", [])):
        output = ROOT / (label + "-result")
        output.mkdir(mode=0o700)
        command = [sys.executable, str(ROOT / "controlled.py"), *names]
        env = {**os.environ, "C060_SUPERVISOR_SOURCE": str(ROOT / label / "outer-run.py"),
               "PYTHONDONTWRITEBYTECODE": "1"}
        started = time.monotonic()
        completed = subprocess.run(command, env=env, cwd=ROOT, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        exclusive(output / "stdout.log", completed.stdout)
        exclusive(output / "stderr.log", completed.stderr)
        runs.append({"label": label, "command": command, "exitCode": completed.returncode,
                     "elapsedSeconds": time.monotonic() - started,
                     "stdoutSHA256": hashlib.sha256(completed.stdout).hexdigest(),
                     "stderrSHA256": hashlib.sha256(completed.stderr).hexdigest()})
    after = bindings()
    result = {"version": 1, "scope": "Inert helper unit controls and real temporary receipt writes; no app/browser/Docker/real signals",
              "before": before, "after": after, "sourcesStable": before == after,
              "runs": runs, "expectedBeforeFailure": runs[0]["exitCode"] == 1,
              "fixedControlsPassed": runs[1]["exitCode"] == 0}
    exclusive(ROOT / "result.json", (json.dumps(result, indent=2) + "\n").encode())
    print(json.dumps({"sourcesStable": result["sourcesStable"], "runs": runs}, indent=2))
    return 0 if result["sourcesStable"] and result["expectedBeforeFailure"] and result["fixedControlsPassed"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
