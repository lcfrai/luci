import hashlib,json,os,pathlib,signal,subprocess,sys,time
stage=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/workspace/luci');mode=sys.argv[1];assert mode in ['before','after'];attempt=sys.argv[2] if len(sys.argv)>2 else '1';out=stage/(mode+'-attempt'+attempt);out.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
paths=sorted(p for p in (repo/'desktop/src').rglob('*') if p.is_file() and p.suffix in ['.ts','.tsx','.css','.json','.svg'])+[repo/'desktop/package.json',repo/'desktop/package-lock.json',repo/'desktop/vitest.config.ts']
def snapshot():return [{'path':str(p.relative_to(repo)),'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes())} for p in paths]
def emit(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
before=snapshot();emit('source-before.json',before);emit('versions.json',{k:subprocess.check_output(cmd,text=True).strip() for k,cmd in {'node':['node','--version'],'npm':['npm','--version'],'head':['git','-C',str(repo),'rev-parse','HEAD']}.items()})
helpers=[]
for name in ['authority-portals.test.tsx','config.mts','run.py']:
 p=stage/name;data=p.read_bytes();(out/name).write_bytes(data);helpers.append({'path':name,'sha256':sha(data),'bytes':len(data)})
if mode=='after':
 for p in sorted((stage/'after').rglob('*')):
  if p.is_file():
   data=p.read_bytes();name=str(p.relative_to(stage));target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);helpers.append({'path':name,'sha256':sha(data),'bytes':len(data)})
emit('helper-bindings.json',helpers)
cmd=['node','node_modules/vitest/vitest.mjs','run','--config',str(stage/'config.mts'),'--maxWorkers=1','--reporter=json','--outputFile='+str(out/'report.json')];env=os.environ.copy();env['CLOUD060_FIXED']='1' if mode=='after' else '0';start=time.time();timeout=False
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(cmd,cwd=repo/'desktop',env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=child.wait(timeout=120)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
after=snapshot();emit('source-after.json',after);result={'mode':mode,'environment':{k:env.get(k) for k in ['CLOUD060_FIXED','CLOUD060_CORE_ONLY','CLOUD060_NESTED_ORIGINAL']},'command':cmd,'exitCode':code,'timedOut':timeout,'seconds':time.time()-start,'sourceStable':before==after,'sourceInputs':len(before),'ownedRootPID':child.pid,'rootWaited':True,'scope':'Controlled actual React/Radix with fixtureHTTP; no real app/browser/Docker/provider; no whole-machine census'};emit('result.json',result);print(json.dumps(result));sys.exit(code)
